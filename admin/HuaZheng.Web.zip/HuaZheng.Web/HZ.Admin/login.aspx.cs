﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using HZ.DBUtility;
namespace HZ.Web
{
    public partial class login : System.Web.UI.Page
    {
        protected System.Data.SqlClient.SqlConnection Cn;
        protected System.Data.SqlClient.SqlCommand Cm;
        protected System.Data.SqlClient.SqlCommand Dm;
        protected System.Data.SqlClient.SqlDataAdapter Da;
        protected System.Data.DataSet Ds;
        protected System.Data.SqlClient.SqlDataReader Dr;
        protected System.Data.SqlClient.SqlDataReader Cr;
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {

                logins();

            }
           
        }

        protected void btn_Click(object sender, EventArgs e)
        {

            logins();

        }

        public void logins()
        {
            string txtUserName = Request.Form["txtUserName"];
            string txtUserPwd = Request.Form["txtUserPwd"];



            DataSet ds = DbHelperSQL.Query("SELECT * FROM users_table WHERE userName='" + txtUserName + "'");
            string json = Newtonsoft.Json.JsonConvert.SerializeObject(ds);

            if (ds.Tables[0].Rows.Count > 0)//用户是否正确
            {
                Session["userName"] = txtUserName;
                this.txtUserName.Value = txtUserName;
               

                DataSet ds1 = DbHelperSQL.Query("SELECT * FROM users_table WHERE userPwd='" + txtUserPwd + "'");

                if (ds1.Tables[0].Rows.Count > 0)//密码是否正确
                {

                    Session["userPwd"] = txtUserPwd;
                    this.txtUserPwd.Value = txtUserPwd;

                    Response.Write("<script>alert('登陆成功');window.location='index.aspx'</script>");


                }
                else
                {

                    Response.Write("<script>alert('密码错误！')</script>");
                }

            }
            else
            {
                if (txtUserName == null)
                {
                    txtUserName = "";
                }
                else
                {
                    Response.Write("<script>alert('用户名输入错误！')</script>");

                }

            }

        }
    }
}