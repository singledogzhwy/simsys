﻿using HZ.BLL;
using HZ.Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ZH.Common;

namespace HZ.Admin.Api
{
    public partial class user : BaseRequest
    {
        protected int recordCount;

        BLL.user_table bll = new BLL.user_table();
        protected void Page_Load(object sender, EventArgs e)
        {
            string action=Request.QueryString["action"];
            switch(action.ToLower())
            {
                 case "detail":
                    Detail();
                    break; 
                case "list":
                    List();
                    break;
            }
        }

        private void List()
        {
            int pageIndex = int.Parse(Request.Form["pageIndex"]);
            if (pageIndex < 1)
            {
                Log.WritePage(Obj2Json.Error("0", "分页页码不能为空"));
                return;
            }
            int pageSize = int.Parse(Request.Form["pageSize"]);
            if (pageSize < 1)
            {
                Log.WritePage(Obj2Json.Error("0", "分页数量不能为空"));
                return;
            }

            #region 查询条件
            string where = "1=1";

            string userID = Request.Form["userID"];
            if (!string.IsNullOrEmpty(userID))
            {
                where += " AND userID = " + userID;
            }

            string userType = Request.Form["userType"];
            if (!string.IsNullOrEmpty(userType))
            {
                where += " AND userType LIKE '%" + userType + "%'";
            }

            string isApi = Request.Form["isApi"];
            if (!string.IsNullOrEmpty(isApi))
            {
                where += " AND isApi LIKE '%" + isApi + "%'";
            }

            string realHierarchy = Request.Form["realHierarchy"];
            if (!string.IsNullOrEmpty(realHierarchy))
            {
                where += " AND realHierarchy = " + realHierarchy;
            }


            #endregion

            IsoDateTimeConverter timeConverter = new IsoDateTimeConverter();
            timeConverter.DateTimeFormat = "yyyy-MM-dd HH:mm:ss";
            string json = JsonConvert.SerializeObject(bll.GetList(pageIndex, pageSize, where, "userID DESC", out recordCount), Formatting.Indented, timeConverter);
            Success("获取用户信息", "{\"infoList\":" + json + ",\"count\": " + recordCount + "}");
        }

        private void Detail()
        {

            //var  userID = _Common.GetSession("userID");

            int userID = 123;
            string json = SQLHelper.ExecuteScalar(new Utils().getConnectionStr(), "indexs_card_static", userID).ToString();

            Log.WritePage(json);
                //int userID=123;
                //users_tableInfo  model=new users_table().GetModel(userID);
                //string json = JsonConvert.SerializeObject(model);
                //Success("获取用户详情", json);
        }
    }
}