﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using HZ.Admin;

namespace HZ.Admin.Api
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            string power = Request.QueryString["power"];
            switch (power.ToLower())
            {
                case "login":
                    Login();
                    break;
            
            }
        }

        private void Login()
        {
            string userName = Request.Form["txtUserName"];
            string userPwd = Request.Form["txtUserPwd"];
           //userPwd = Utils.MD5(userPwd);

           
            string vcResult = SQLHelper.ExecuteScalar(new Utils().getConnectionStr(), "P_index_Login", userName, userPwd).ToString();
            string[] result = vcResult.Split('|');
            if (result[0] == "SUCCESS")
            {
              

                int nAdminID = _Common.SafeInt(result[1]);
                _Common.SetSession("Admin", new RuleUser(userName, nAdminID));
                Log.WritePage("SUCCESS");
            }
            Log.WritePage("SUCCESS");
        }
    }
}
namespace HZ.Admin
{
    public class RuleUser
    {  
        /// <summary>
        /// 后台登录名
        /// </summary>
        public string vcUserName { get; set; }

        public int nAdminID { get; set; }

        public RuleUser(string _username, int _adminID)
        {
            vcUserName = _username;
            nAdminID = _adminID;
        }
    }
}
