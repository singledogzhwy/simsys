﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ZH.Common;

namespace HZ.Admin.Api
{
    public partial class orders : BaseRequest
    {
        protected int recordCount;
        BLL.order_table bll = new BLL.order_table();
        protected void Page_Load(object sender, EventArgs e)
        {
            string action=Request.QueryString["action"];
            switch (action)
            { 
            
                case "list":
                    List();
                    break;
            }
        }

        private void List()
        {
            int pageIndex = int.Parse(Request.Form["pageIndex"]);
            if (pageIndex < 1)
            {
                Log.WritePage(Obj2Json.Error("0", "分页页码不能为空"));
                return;
            }
            int pageSize = int.Parse(Request.Form["pageSize"]);
            if (pageSize < 1)
            {
                Log.WritePage(Obj2Json.Error("0", "分页数量不能为空"));
                return;
            }

            #region 查询条件
            string where = "1=1";

            string sim = Request.Form["sim"];
            if (!string.IsNullOrEmpty(sim))
            {
                where += " AND sim = " + sim;
            }

            string orderId = Request.Form["orderId"];
            if (!string.IsNullOrEmpty(orderId))
            {
                where += " AND orderId LIKE '%" + orderId + "%'";
            }

            string isOpen = Request.Form["isOpen"];
            if (!string.IsNullOrEmpty(isOpen))
            {
                where += " AND isOpen LIKE '%" + isOpen + "%'";
            }

            string rnwStatus = Request.Form["rnwStatus"];
            if (!string.IsNullOrEmpty(rnwStatus))
            {
                where += " AND rnwStatus = " + rnwStatus;
            }

            string cardCompany = Request.Form["cardCompany"];
            if (!string.IsNullOrEmpty(cardCompany))
            {
                where += " AND cardCompany = " + cardCompany;
            }

            string cardType = Request.Form["cardType"];
            if (!string.IsNullOrEmpty(cardType))
            {
                where += " AND cardType = " + cardType;
            }

            string iccid = Request.Form["iccid"];
            if (!string.IsNullOrEmpty(iccid))
            {
                where += " AND iccid = " + iccid;
            }

            #endregion

            IsoDateTimeConverter timeConverter = new IsoDateTimeConverter();
            timeConverter.DateTimeFormat = "yyyy-MM-dd HH:mm:ss";
            string json = JsonConvert.SerializeObject(bll.GetList(pageIndex, pageSize, where, "sim DESC", out recordCount), Formatting.Indented, timeConverter);
            Success("获取订单号信息", "{\"infoList\":" + json + ",\"count\": " + recordCount + "}");


        }
    }
}