﻿using HZ.BLL;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ZH.Common;

namespace HZ.Admin.Api
{
    public partial class Renewalcodes :BaseRequest
    {
        protected int recordCount;
        protected void Page_Load(object sender, EventArgs e)
        {
            string action = Request.QueryString["action"];
            switch(action)
            {

                case "list":
                    List();
                    break;
            }
        }

        private void List()
        {
            int pageIndex = int.Parse(Request.Form["pageIndex"]);
            if (pageIndex < 1)
            {
                Log.WritePage(Obj2Json.Error("0", "分页页码不能为空"));
                return;
            }
            int pageSize = int.Parse(Request.Form["pageSize"]);
            if (pageSize < 1)
            {
                Log.WritePage(Obj2Json.Error("0", "分页数量不能为空"));
                return;
            }

            #region 查询条件
            string where = "1=1";

            #endregion

            IsoDateTimeConverter timeConverter = new IsoDateTimeConverter();
            timeConverter.DateTimeFormat = "yyyy-MM-dd HH:mm:ss";
            string json = JsonConvert.SerializeObject(new Renewalcode_table().GetList(pageIndex, pageSize, where, "rnwCode DESC", out recordCount), Formatting.Indented, timeConverter);
            Success("获取充值码信息", "{\"infoList\":" + json + ",\"count\": " + recordCount + "}");  
        }
    }
}