﻿using HZ.Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ZH.Common;

namespace HZ.Admin.Api
{
    public partial class Cards : BaseRequest
    {
        protected int recordCount;

        BLL.card_table bll = new BLL.card_table();
        protected void Page_Load(object sender, EventArgs e)
        {
            string action = Request.QueryString["action"];
            switch (action)
            { 
                case "list":
                    List();
                    break;
                case "detail":
                    Deatil();
                    break;
                case "edit":
                    Edit();
                    break;
            }
        }

        private void Edit()
        {
            #region 参数检查

            #endregion

            bool result = new BLL.card_table().Update(new card_tableInfo()
                {
                        sim=123,
                        //pkgId=int.Parse(Request.Form["pkgID"]),
                        //cardType=int.Parse(Request.Form["cardType"]),
                        //terminal = Request.Form["terminal"],
                        isOpen= Request.Form["isOpen"] == "1" ? true:false
                });
            if (result)
            {
                SuccessWithNoData("修改成功");
            }
            else
            {
                Errors("0", "修改失败");
            }
        }


     
        private void Deatil()
        {
            

            IsoDateTimeConverter timeConverter = new IsoDateTimeConverter();
            timeConverter.DateTimeFormat = "yyyy-MM-dd HH:mm:ss";

            card_tableInfo model = bll.GetModel(int.Parse(Request.Form["sim"]));
            string json = JsonConvert.SerializeObject(model, Formatting.Indented, timeConverter);
            Success("sim卡详情", json);
        }

        private void List()
        {
            int pageIndex = int.Parse(Request.Form["pageIndex"]);
            if (pageIndex < 1)
            {
                Log.WritePage(Obj2Json.Error("0", "分页页码不能为空"));
                return;
            }
            int pageSize = int.Parse(Request.Form["pageSize"]);
            if (pageSize < 1)
            {
                Log.WritePage(Obj2Json.Error("0", "分页数量不能为空"));
                return;
            }

            #region 查询条件
            string where = "1=1";

            string sim = Request.Form["sim"];
            if (!string.IsNullOrEmpty(sim))
            {
                where += " AND sim = " + sim;
            }

            string ICCID = Request.Form["ICCID"];
            if (!string.IsNullOrEmpty(ICCID))
            {
                where += " AND ICCID LIKE '%" + ICCID + "%'";
            }

            string isOpen = Request.Form["isOpen"];
            if (!string.IsNullOrEmpty(isOpen))
            {
                where += " AND isOpen LIKE '%" + isOpen + "%'";
            }

            string isGprs = Request.Form["isGprs"];
            if (!string.IsNullOrEmpty(isGprs))
            {
                where += " AND isGprs = " + isGprs;
            }

            string cardCompany = Request.Form["cardCompany"];
            if (!string.IsNullOrEmpty(cardCompany))
            {
                where += " AND cardCompany = " + cardCompany;
            }

            string card = Request.Form["card"];
            if (!string.IsNullOrEmpty(card))
            {
                where += " AND card = " + card;
            }

            string terminal = Request.Form["terminal"];
            if (!string.IsNullOrEmpty(terminal))
            {
                where += " AND terminal = " + terminal;
            }
           
            #endregion

            IsoDateTimeConverter timeConverter = new IsoDateTimeConverter();
            timeConverter.DateTimeFormat = "yyyy-MM-dd HH:mm:ss";
            string json = JsonConvert.SerializeObject(bll.GetList(pageIndex, pageSize, where, "sim DESC", out recordCount), Formatting.Indented, timeConverter);
            Success("获取SIM号信息", "{\"infoList\":" + json + ",\"count\": " + recordCount + "}");


        }
    }
}