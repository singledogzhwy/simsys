﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ZH.Common;

namespace HZ.Admin.Api
{
    public partial class BaseRequest : System.Web.UI.Page
    {

        public bool CheckMethod()
        {
            if (Request.HttpMethod.ToUpper() != "POST")
            {
                Errors("0", "请求类型错误");
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool CheckForm(string key, string message, bool isRequired)
        {
            if (isRequired)
            {
                if (Request.Form[key] == null || Request.Form[key] == "")
                {
                    Errors("0", message);
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                if (Request.Form[key] == null)
                {
                    Errors("0", message);
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }

        public void Errors(string code,string message)
        {
            Log.WritePage(Obj2Json.Error(code,message));
        }

        public void Success(string message,string data)
        {
            Log.WritePage(Obj2Json.Success(message, data));
        }

        public void SuccessWithNoData(string message)
        { 
            Log.WritePage(Obj2Json.SuccessWithNoData(message));
        }

    }


}