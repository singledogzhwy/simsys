﻿
$(document).ready(function () {
    //5分钟进行轮询 Session登录状态
    (function () {
        setTimeout(function () {
            IsLogin();
        }, 300000);
    })();

    //是否登录
    function IsLogin() {
        $.ajax({
            type: "POST",
            url: "/Api/RuleManager.aspx?power=islogin",
            data: {},
            success: function (val) {

                if (val == "NOT_LOGIN") {
                    layer.msg("登录超时或失败,请重新登录!", { shade: [1.0, '#000'], icon: 2, time: 1000 });

                    $("body").css("display", "inline");
                    setTimeout(function () {
                        window.location.href = "/Login.aspx";
                    }, 1000);
                }
                $(document).css("display", "block"); 
            }
        });
    }


    //获取权限菜单
    (function GetRuleMenu() {
        var menuHtml = "<li id=\"parli_000\" class=\"sub-menu\"><a class=\"\" href=\"/index.aspx\"><i class=\"icon-dashboard\"></i><span>控制台</span></a></li>";
        $(".sidebar-menu").html("");
        $.ajax({
            type: "POST",
            url: "/Api/RuleManager.aspx?power=menu",
            data: {},
            dataType:"json",
            success: function (json) {
                //if (result == "NOT_LOGIN") {
                //    layer.msg("登录超时,请重新登录", { shade: [1.0, '#000'], icon: 2 });
                //    setTimeout(function () { window.location.href = "main.htm?act=login"; }, 800);
                //    return;
                //}
                var currentHref = "http://" + window.location.host;
                var act_id = 0, act_parentid = 0;
                for (var i = 0; i < json.length; i++) {
                    var parentId = json[i].parentId;
                    if (parentId == "0") {
                        var childHtml = "";
                        for (var j = 0; j < json.length; j++) {
                            if (json[i].id == json[j].parentId) {
                                if (json[j].href == currentHref) {
                                    act_id = json[j].id;
                                    act_parentid = json[j].parentId;
                                }
                                childHtml += "<li id=\"li_" + json[j].id + "\" ><a class=\"\" href=\"" + json[j].href + "\">" + json[j].name + "</a></li>";
                            }
                        }
                        if (childHtml == "") {
                            menuHtml += "<li class=\"sub-menu\" id=\"parli_" + json[i].id + "\">";
                            menuHtml += "   <a href=\"" + json[i].href + "\" class=\"\">";
                            menuHtml += "       <span>" + json[i].name + "</span>";
                            menuHtml += "   </a>";
                            menuHtml += "</li>";
                        } else {
                            menuHtml += "<li class=\"sub-menu\" id=\"parli_" + json[i].id + "\">";
                            menuHtml += "   <a href=\"javascript:;\" class=\"\">";
                            menuHtml += "       <span>" + json[i].name + "</span>";
                            menuHtml += "       <span class=\"arrow\"></span>";
                            menuHtml += "   </a>";
                            menuHtml += "   <ul class=\"sub\">";
                            menuHtml += childHtml;
                            menuHtml += "   </ul>";
                            menuHtml += "</li>";
                        }
                    }
                }

                $(".sidebar-menu").html(menuHtml);
                $(".sidebar-menu").append(
                    "<li class=\"sub-menu\">" +
                        "<a href=\"javascript:;\" onclick=\"LoginOut();\" class=\"\">" +
                            "<span>退出登录</span>" +
                        "</a>" +
                    "</li>"
                );

                if (act_parentid != 0) {
                    $("#parli_" + act_parentid).attr("class", "sub-menu active");
                } else {
                    $("#parli_000").attr("class", "sub-menu active");
                }
                if (act_id != 0) {
                    $("#li_" + act_id).attr("class", "active");
                }
                ShildStyleJS();
            }, error: function (e) {

            }
        });
    })();

    //菜单样式
    function ShildStyleJS() {

        $('#sidebar .sub-menu > a').click(function () {
            var last = $('.sub-menu.open', $('#sidebar'));
            last.removeClass("open");
            $('.arrow', last).removeClass("open");
            $('.sub', last).slideUp(200);
            var sub = $(this).next();
            if (sub.is(":visible")) {
                $('.arrow', jQuery(this)).removeClass("open");
                $(this).parent().removeClass("open");
                sub.slideUp(200);
            } else {
                $('.arrow', jQuery(this)).addClass("open");
                $(this).parent().addClass("open");
                sub.slideDown(200);
            }
            var o = ($(this).offset());
            diff = 200 - o.top;
            if (diff > 0)
                $(".sidebar-scroll").scrollTo("-=" + Math.abs(diff), 500);
            else
                $(".sidebar-scroll").scrollTo("+=" + Math.abs(diff), 500);
        });
    }

    //弹出框配置
    (function () {
        layer.config({
            extend: '/skin/moon/style.css',
            skin: 'layer-ext-moon',
            shade: 0.8,
            shift: 5,
        });
    })();


});