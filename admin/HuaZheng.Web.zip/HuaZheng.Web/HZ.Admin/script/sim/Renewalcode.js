﻿var intPageIndex = 1;
var intRecordCount = 0;
var intPageSize = 20;
var formdata = new FormData();
$(function () {

    LoadData(1);
})

function LoadData(index) {

    $("html,body").animate({ scrollTop: 0 });
    intPageIndex = index;
    $("#ul_list").html("<div style=\"width:30px;margin:0 auto;margin-top:20px;\"><img src=\"../../images/loading.gif\" /></div>");
    setTimeout(function () {
        getdata();
    }, 500);
}


function getdata() {
    $.ajax({
        url: "/api/Renewalcodes.aspx?action=list",
        type: "POST",
        dataType: "json",
        data: {  
            pageIndex: intPageIndex,
            pageSize: intPageSize
        }, success: function (json) {
            var _html = "";
            var _height = 0;
            _html +=
                    "<thead class=\"thead-text\">" +
                        "<tr>" +
                        "<th> <input type=\"checkbox\" class=\"ckAll\" id=\"checkAll\" name=\"checkAll\"  onclick=\"swapCheck()\" value=\"全选\" /> </th>" +
                             "<th >序号</th>" +
                            "<th >充值码</th>" +
                            "<th> 套餐类型</th>" +
                            "<th>周期</th>" +
                            "<th>数量</th>" +
                            "<th>所属用户</th>" +
                            "<th>充值用户</th>" +
                            "<th>生成时间</th>" +
                            "<th>充值时间</th>" +
                            "<th>操作</th>" +                     
                        "</tr>" +
                    "</thead>" +
                    "<tbody class=\"tbody-text\">";

            if (json.error == "1") {
                intRecordCount = json.data.count;
                var pageHtml = PageList("SelectPage");
                $("#pageHtml").html(pageHtml);

                var list = json.data.infoList;

                for (var i = 0; i < list.length; i++) {
                    _height += 58;
                    _html += "<tr>" +
                        "<td>" +
                                 "<input  id=\"checkId\" name=\"checkId\" class=\"ckUser\"onchange=\"Getcheckbox()\" type=\"checkbox\" val=\"(" + list[i].srnwCodeim + ")\" />" +
                                  "<td>" + i + "</td>" +  
                                 "<td>" + list[i].rnwCode + "</td>" +
                                 "<td>" + list[i].pkgId + "</td>" +
                                 "<td>" + list[i].codeCount + "</td>" +
                                 "<td>" + list[i].codeCount + "</td>" +
                                  "<td>" + list[i].usreId + "</td>" +
                                 "<td>" + list[i].initialPeriod + "</td>" +
                                 "<td>" + list[i].crtTime + "</td>" +
                                 "<td>" + list[i].useTime + "</td>" +
                                 "<td>" + list[i].spsFlow + "</td>" +
                             "</tr>";
                }
                if (list.length == 0) {
                    _html += "<tr><td colspan=20><div style=\"width:200px;margin:0 auto;margin-top:20px;\">暂无数据</div></td></tr>";
                }
                _html += "</tbody>";
                $("#ul_list").css("display", "none");
                $("#ul_list").animate({ opacity: 'show', height: _height + "px" }, 'slow').html(_html);

            }

        }, error: function (error) {
            alert("error");
        }
    })

}

//全选
var isCheckAll = false;
function swapCheck() {
    if (isCheckAll) {
        $("input[type='checkbox']").each(function () {
            this.checked = false;
            Getcheckbox();
        });
        isCheckAll = false;
    } else {
        $("input[type='checkbox']").each(function () {
            this.checked = true;
            Getcheckbox();
        });
        isCheckAll = true;
    }
}
function Getcheckbox() {
    var str = document.getElementsByName("checkId");
    var objarray = str.length;
    var chestr = "";
    for (i = 0; i < objarray; i++) {
        if (str[i].checked == true) {
            chestr += str[i].value + ":";
        }
    }
    document.getElementById("checkId").value = chestr;
}


