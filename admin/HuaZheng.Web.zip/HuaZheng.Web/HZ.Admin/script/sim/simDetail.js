﻿$(function () {

    //获取卡号详细信息
    getSimsDetail();
})

//获取sim卡号详情
function getSimsDetail() {

    
    $.ajax({
        url: "/api/Cards.aspx?action=detail",
        type: "POST",
        dataType: "json",
        data: {
            sim: getpara("sim")
        }, success: function (json) {
            var res = json.data;
            if (json.error == "1") {
                $("#ICCID").val(res.ICCID);
                $("#sim").val(res.sim);
                $("#initialValue").val(res.initialValue);
                $("#message").val(res.message);
                $("#card").val(res.card);
                $("#initialPeriod").val(res.initialPeriod);
             
            }
        }, error: function (error) {
            alert(error);
        }
    })
}