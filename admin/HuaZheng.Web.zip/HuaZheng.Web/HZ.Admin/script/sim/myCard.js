﻿var intPageIndex = 1;
var intRecordCount = 0;
var intPageSize = 20;
var formdata = new FormData();
$(function () {

    

    LoadData(1);
})

function LoadData(index) {

    $("html,body").animate({ scrollTop: 0 });
    intPageIndex = index;
    $("#ul_list").html("<div style=\"width:30px;margin:0 auto;margin-top:20px;\"><img src=\"../../images/loading.gif\" /></div>");
    setTimeout(function () {
        getdata();
    }, 500);
}


$("#btn_search").click(function () {
    LoadData(1);
})


$("#btn_sim").click(function () {
    LoadData(1);
})


function getdata() {
    $.ajax({
        url: "/api/Cards.aspx?action=list",
        type: "POST",
        dataType: "json",
        data: {
            sim: $("#sim").val(),
            isOpen: $("#isOpen").val(),
            isGprs: $("#isGprs").val(),
            pageIndex: intPageIndex,
            pageSize: intPageSize
        }, success: function (json) {
            var _html = "";
            var _height = 0;
            _html +=
                    "<thead class=\"thead-text\">" +
                        "<tr>" +
                        "<th> <input type=\"checkbox\" class=\"ckAll\" id=\"checkAll\" name=\"checkAll\"  onclick=\"swapCheck()\" value=\"全选\" /> </th>" +
                             "<th >序号</th>" +
                            "<th >sim卡号</th>" +
                            "<th> ICCID号</th>" +
                            "<th>所属用户</th>" +
                            "<th>套餐类型</th>" +
                            "<th>初始周期</th>" +
                            "<th>初始面值</th>" +
                            "<th>余额</th>" +
                            "<th>剩余流量</th>" +
                            "<th>停开机</th>" +
                            "<th>状态</th>" +
                            "<th>激活</th>" +
                            "<th>账单</th>" +
                            "<th>到期时间</th>" +
                            "<th>GPRS停开机</th>" +
                            "<th>卡的类型</th>" +
                            "<th>短信</th>" +
                            "<th>卡源</th>" +
                            "<th>实名</th>" +
                            "<th>续费记录</th>" +
                        "</tr>" +
                    "</thead>" +
                    "<tbody class=\"tbody-text\">";

            if (json.error == "1") {
                intRecordCount = json.data.count;
                var pageHtml = PageList("SelectPage");
                $("#pageHtml").html(pageHtml);

                var list = json.data.infoList; 

                for (var i = 0; i < list.length; i++) {
              
                    _height += 58;
                    _html += "<tr>" +
                        "<td>" +
                                 "<input  id=\"checkId\" name=\"checkId\" class=\"ckUser\"onchange=\"Getcheckbox()\" type=\"checkbox\" val=\"" + list[i].sim + "\" />" +
                                  "<td>" + i + "</td>" +
                                 "<td >" + " <a class=\"sim-btn\" onclick=\"Update(" + list[i].sim + ")\">" + list[i].sim + "</a> " + "</td>" +
                                 "<td>" + list[i].ICCID + "</td>" +
                                  "<td>" + list[i].userId + "</td>" +
                                 "<td>" + list[i].pkgId + "</td>" +
                                 "<td>" + list[i].initialPeriod + "</td>" +
                                 "<td>" + list[i].initialValue + "</td>" +
                                 "<td>" + list[i].balance + "</td>" +
                                 "<td>" + list[i].spsFlow + "</td>" +
                                 "<td>" + (list[i].isOpen == false ? "停机" : "正常") + "</td>" +
                                 "<td>" + list[i].cardType + "</td>" +
                                 "<td>" + (list[i].isActivation == false ? "否" : "是") + "</td>" +
                                 "<td>" + " <a class=\"sim-btn\"  href=\"/Controller/sims/simDetail.aspx?sim=" + list[i].sim + "\">查看</a> " + "</td>" +
                                 "<td>" + list[i].expireTime + "</td>" +
                                 "<td>" + (list[i].isGprs == false ? "停机" : "开机") + "</td>" +
                                 "<td>" + list[i].cardType + "</td>" +
                                 "<td>" + (list[i].isMessage == false ? "否" : "是") + "</td>" +
                                 "<td>" + list[i].card + "</td>" +
                                 "<td>" + (list[i].isRealname == false ? "否" : "是") + "</td>" +
                                 "<td>" + list[i].isRealName + "</td>" +
                                 
                             "</tr>";
                }
                if (list.length == 0) {
                    _html += "<tr><td colspan=20><div style=\"width:200px;margin:0 auto;margin-top:20px;\">暂无数据</div></td></tr>";
                }
                _html += "</tbody>";
                $("#ul_list").css("display", "none");
                $("#ul_list").animate({ opacity: 'show', height: _height + "px" }, 'slow').html(_html);

            }

        }, error: function (error) {
            alert("error");
        }
    })

}

//全选
var isCheckAll = false;
function swapCheck() {
    if (isCheckAll) {
        $("input[type='checkbox']").each(function () {
            this.checked = false;
            Getcheckbox();
        });
        isCheckAll = false;
    } else {
        $("input[type='checkbox']").each(function () {
            this.checked = true;
            Getcheckbox();
        });
        isCheckAll = true;
    }
}
function Getcheckbox() {
    var str = document.getElementsByName("checkId");
    var objarray = str.length;
    var chestr = "";
    for (i = 0; i < objarray; i++) {
        if (str[i].checked == true) {
            chestr += str[i].value + ":";
        }
    }
    document.getElementById("checkId").value = chestr;
}

//查看卡片详情
function Update(sim) {
    layer.open({
        title: false,
        type: 2,
        shadeClose: true,
        scrollbar: false,
        area: ['700px', '350px'],
        content: '/Controller/sims/simDetail.aspx?sim=' + sim
    });
}