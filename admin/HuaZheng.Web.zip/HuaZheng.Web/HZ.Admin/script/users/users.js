﻿var intPageIndex = 1;
var intRecordCount = 0;
var intPageSize = 20;
var formdata = new FormData();
$(function () {



    LoadData(1);
})

function LoadData(index) {

    $("html,body").animate({ scrollTop: 0 });
    intPageIndex = index;
    $("#ul_list").html("<div style=\"width:30px;margin:0 auto;margin-top:20px;\"><img src=\"../../images/loading.gif\" /></div>");
    setTimeout(function () {
        getdata();
    }, 500);
}


$("#btn_search").click(function () {
    LoadData(1);
})


$("#btn_sim").click(function () {
    LoadData(1);
})


function getdata() {
    $.ajax({
        url: "/api/user.aspx?action=list",
        type: "POST",
        dataType: "json",
        data: {
            userID: $("#userID").val(),
            userType: $("#userType").val(),
            isApi: $("#isApi").val(),
            realHierarchy: $("#realHierarchy").val(),
            pageIndex: intPageIndex,
            pageSize: intPageSize
        }, success: function (json) {
            var _html = "";
            var _height = 0;
            _html +=
                    "<thead class=\"thead-text\">" +
                        "<tr>" +
                        "<th> <input type=\"checkbox\" class=\"ckAll\" id=\"checkAll\" name=\"checkAll\"  onclick=\"swapCheck()\" value=\"全选\" /> </th>" +
                             "<th >序号</th>" +
                            "<th >用户名称</th>" +
                            "<th> 上级用户</th>" +
                            "<th>openApi</th>" +
                            "<th>续费卡</th>" +
                            "<th>上月开通</th>" +
                            "<th>所有</th>" +
                            "<th>类型</th>" +
                            "<th>激活</th>" +
                            "<th>实名等级</th>" +
                            "<th>联系人</th>" +
                            "<th>联系电话</th>" +
                            "<th>操作</th>" +
                            "<th>创建时间</th>" +   
                        "</tr>" +
                    "</thead>" +
                    "<tbody class=\"tbody-text\">";

            if (json.error == "1") {
                intRecordCount = json.data.count;
                var pageHtml = PageList("SelectPage");
                $("#pageHtml").html(pageHtml);

                var list = json.data.infoList;

                for (var i = 0; i < list.length; i++) {

                    _height += 58;
                    _html += "<tr>" +
                        "<td>" +
                                 "<input  id=\"checkId\" name=\"checkId\" class=\"ckUser\"onchange=\"Getcheckbox()\" type=\"checkbox\" val=\"" + list[i].userID + "\" />" +
                                  "<td>" + i + "</td>" +
                                 "<td >" + " <a class=\"sim-btn\" onclick=\"Update(" + list[i].userID + ")\">" + list[i].userID + "</a> " + "</td>" +
                                 "<td>" + list[i].sprUserid + "</td>" +
                                  "<td>" + list[i].isApi + "</td>" +      
                                 "<td>" + list[i].cardrnwSum + "</td>" +
                                 "<td>" + list[i].initialValue + "</td>" +
                                 "<td>" + list[i].cardSum + "</td>" +
                                 "<td>" + list[i].userType + "</td>" +
                                 "<td>" + (list[i].isOpen == false ? "停机" : "正常") + "</td>" +
                                 "<td>" + list[i].realHierarchy + "</td>" +
                                 "<td>" + list[i].contacts + "</td>" +
                                  "<td>" + list[i].phone + "</td>" +
                                 "<td>" + " <a class=\"sim-btn\"  href=\"/Controller/sim/simDetail.aspx?userID=" + list[i].userID + "\">查看</a> " + "</td>" +
                                 "<td>" + list[i].expireTime + "</td>" +
                             "</tr>";
                }
                if (list.length == 0) {
                    _html += "<tr><td colspan=20><div style=\"width:200px;margin:0 auto;margin-top:20px;\">暂无数据</div></td></tr>";
                }
                _html += "</tbody>";
                $("#ul_list").css("display", "none");
                $("#ul_list").animate({ opacity: 'show', height: _height + "px" }, 'slow').html(_html);

            }

        }, error: function (error) {
            alert("error");
        }
    })

}

//全选
var isCheckAll = false;
function swapCheck() {
    if (isCheckAll) {
        $("input[type='checkbox']").each(function () {
            this.checked = false;
            Getcheckbox();
        });
        isCheckAll = false;
    } else {
        $("input[type='checkbox']").each(function () {
            this.checked = true;
            Getcheckbox();
        });
        isCheckAll = true;
    }
}
function Getcheckbox() {
    var str = document.getElementsByName("checkId");
    var objarray = str.length;
    var chestr = "";
    for (i = 0; i < objarray; i++) {
        if (str[i].checked == true) {
            chestr += str[i].value + ":";
        }
    }
    document.getElementById("checkId").value = chestr;
}

//查看卡片详情
function Update(sim) {
    layer.open({
        title: false,
        type: 2,
        shadeClose: true,
        scrollbar: false,
        area: ['700px', '350px'],
        content: '/Controller/sim/simDetail.aspx?sim=' + sim
    });
}