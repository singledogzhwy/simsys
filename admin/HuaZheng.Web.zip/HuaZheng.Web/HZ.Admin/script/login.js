﻿

$(".rule_username,.rule_password")
    .focus(function () {
        document.onkeydown = function (event) {
            var e = event || window.event || arguments.callee.caller.arguments[0];
            if (e && e.keyCode == 13) {
                Login();
            }
        }
    })
    .blur(function () {
        document.onkeydown = function (event) { }
    });

$("#loginBtn").click(function () {
    Login();
});

function Login() {
  
    var userName = $("#txtUserName").val().trim();
    var userPwd = $("#txtUserPwd").val().trim();
   


    $.ajax({
        type: "POST",
        url: "Api/login.aspx?power=login",
        data: {
            userName: userName,
            userPwd: userPwd,     
        }, success: function (val) {
           
            if (val == "SUCCESS") {
               window.location.href = "index.aspx";
              
            } else {
                layer.msg("用户名密码错误，登录失败", { shade: [0.6, '#000'], icon: 2 });
            }
        }, error: function (e) {

        }
    });
}