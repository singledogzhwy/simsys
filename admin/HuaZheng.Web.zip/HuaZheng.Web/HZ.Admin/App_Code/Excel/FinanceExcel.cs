﻿using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

namespace ZH.Admin.App_Code.Excel
{
    public class FinanceExcel
    {

        readonly int EXCEL03_MaxRow = 65535;

        /// <summary>
        /// 财务明细记录
        /// </summary>
        public byte[] FinanceLog(System.Data.DataTable dt, string sheetName)
        {
            IWorkbook book = new HSSFWorkbook();
            if (dt.Rows.Count < EXCEL03_MaxRow)
            {
                int startRow = 0;
                int endRow = dt.Rows.Count - 1;

                ISheet sheet = book.CreateSheet(sheetName);
                IRow header = sheet.CreateRow(0);
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    ICell cell = header.CreateCell(i);
                    string val = dt.Columns[i].Caption ?? dt.Columns[i].ColumnName;

                    cell.SetCellValue(val);
                }
                int rowIndex = 1;
                for (int i = startRow; i <= endRow; i++)
                {
                    DataRow dtRow = dt.Rows[i];
                    IRow excelRow = sheet.CreateRow(rowIndex++);

                    for (int j = 0; j < dtRow.ItemArray.Length; j++)
                    {
                        var temp = dtRow[j].ToString();
                        if (temp.Contains("br"))
                        {
                            temp = dtRow[j].ToString().Replace("br", "\r\n");
                        }
                        ICell ic = excelRow.CreateCell(j);
                        ic.SetCellValue(temp);
                    }
                }

            }
            MemoryStream ms = new MemoryStream();
            book.Write(ms);
            return ms.ToArray();
        }
    }
}