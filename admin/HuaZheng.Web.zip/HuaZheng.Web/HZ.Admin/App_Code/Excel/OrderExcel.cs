﻿using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

namespace ZH.Admin.App_Code.Excel
{
    public class OrderExcel
    {
        readonly int EXCEL03_MaxRow = 65535;

        /// <summary>
        /// 物流记录（未发货订单）
        /// </summary>
        public byte[] ExpressExcel(System.Data.DataTable dt, string sheetName, DateTime dtBeginTime, DateTime dtEndTime)
        {
            IWorkbook book = new HSSFWorkbook();
            if (dt.Rows.Count < EXCEL03_MaxRow)
            {
                int startRow = 0;

                int rowIndex = 1;
                int endRow = dt.Rows.Count - 1;

                int hidIndex = -1;
                ISheet sheet = book.CreateSheet(sheetName);
                IRow header = sheet.CreateRow(0);

                //创建标题

                //IRow excelRow = sheet.CreateRow(rowIndex++);
                //for (int i = 0; i < dt.Columns.Count; i++)
                //{
                //    excelRow.CreateCell(i).SetCellValue(dtBeginTime.ToString("yyyy-MM-dd") + " ~ " + dtEndTime.ToString("yyyy-MM-dd"));
                //}
                //sheet.AddMergedRegion(new CellRangeAddress(1, 1, 0, dt.Columns.Count));

                IRow excelRow = null;
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    ICell cell = header.CreateCell(i);
                    string val = dt.Columns[i].Caption ?? dt.Columns[i].ColumnName;

                    if (val == "Count")
                    {
                        cell.SetCellValue("订单总商品数量");
                        hidIndex = i;
                        continue;
                    }
                    else
                    {
                        cell.SetCellValue(val);
                    }
                }

                for (int i = startRow; i <= endRow; i++)
                {
                    DataRow dtRow = dt.Rows[i];
                    excelRow = null;

                    var lineColuIndex = -1;
                    var count1 = false;
                    for (int j = 0; j < dtRow.ItemArray.Length; j++)
                    {
                        var count = _Common.SafeInt(dtRow["Count"].ToString());
                        if (count > 1)
                        {
                            for (int c = 0; c < count; c++)
                            {
                                excelRow = sheet.CreateRow(rowIndex++);
                                for (int k = 0; k < dtRow.ItemArray.Length; k++)
                                {
                                    var val = dtRow[k].ToString();
                                    if (val.Contains("|"))
                                    {
                                        lineColuIndex = k;
                                        val = val.Substring(0, val.Length - 1).Split('|')[c].ToString();
                                        excelRow.CreateCell(k).SetCellValue(val);
                                    }
                                    else
                                    {
                                        excelRow.CreateCell(k).SetCellValue(val);
                                    }

                                    sheet.SetColumnWidth(k, (val.Length < 3 ? 5 : val.Length) * 550);
                                    continue;
                                }
                            }
                            for (int cc = 0; cc < dtRow.ItemArray.Length; cc++)
                            {
                                if (cc != lineColuIndex)
                                {
                                    sheet.AddMergedRegion(new CellRangeAddress(rowIndex - count, rowIndex - 1, cc, cc));
                                }
                            }
                            //sheet.SetColumnHidden(hidIndex, true);
                            AddBorder(sheet, book, rowIndex, dtRow.ItemArray.Length);
                            break;
                        }
                        else
                        {
                            count1 = true;
                            break;
                        }
                    }

                    if (count1 == true)
                    {
                        excelRow = sheet.CreateRow(rowIndex++);
                        for (int j = 0; j < dtRow.ItemArray.Length; j++)
                        {
                            var val = dtRow[j].ToString();
                            if (val.Contains("|"))
                            {
                                val = val.Substring(0, val.Length - 1);
                            }
                            excelRow.CreateCell(j).SetCellValue(val);
                            sheet.SetColumnWidth(j, (val.Length < 3 ? 5 : val.Length) * 550);
                        }
                        //sheet.SetColumnHidden(hidIndex, true);
                        AddBorder(sheet, book, rowIndex, dtRow.ItemArray.Length);
                    }
                }








            }
            MemoryStream ms = new MemoryStream();
            book.Write(ms);
            return ms.ToArray();
        }

        public byte[] SettlementExcel(DataTable dt, string sheetName, DateTime _dtBeginTime, DateTime _dtEndTime)
        {
            IWorkbook book = new HSSFWorkbook();
            if (dt.Rows.Count < EXCEL03_MaxRow)
            {
                int startRow = 0;

                int rowIndex = 1;
                int endRow = dt.Rows.Count - 1;

                int hidIndex = -1;
                ISheet sheet = book.CreateSheet(sheetName);
                IRow header = sheet.CreateRow(0);

                IRow excelRow = null;
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    ICell cell = header.CreateCell(i);
                    string val = dt.Columns[i].Caption ?? dt.Columns[i].ColumnName;

                    if (val == "订单号")
                    {
                        cell.SetCellValue("订单号");
                        hidIndex = i;
                        continue;
                    }
                    else
                    {
                        cell.SetCellValue(val);
                    }
                }

                var currSerialNo = "";
                for (int i = startRow; i <= endRow; i++)
                {
                    DataRow dtRow = dt.Rows[i];
                    excelRow = null;

                    var lineColuIndex = -1;
                    if (currSerialNo == dtRow["订单号"].ToString())
                    {
                        sheet.AddMergedRegion(new CellRangeAddress(i, i + 1, 7, 7));
                        sheet.AddMergedRegion(new CellRangeAddress(i, i + 1, 8, 8));
                        sheet.AddMergedRegion(new CellRangeAddress(i, i + 1, 9, 9));
                        sheet.AddMergedRegion(new CellRangeAddress(i, i + 1, 10, 10));
                    }

                    for (int j = 0; j < dtRow.ItemArray.Length; j++)
                    {

                        excelRow = sheet.CreateRow(rowIndex++);
                        for (int k = 0; k < dtRow.ItemArray.Length; k++)
                        {
                            var val = dtRow[k].ToString();
                            if (val.Contains("|"))
                            {
                                lineColuIndex = k;
                                excelRow.CreateCell(k).SetCellValue(val);
                            }
                            else
                            {
                                excelRow.CreateCell(k).SetCellValue(val);
                            }

                            sheet.SetColumnWidth(k, (val.Length < 3 ? 5 : val.Length) * 550);
                            continue;
                        }
                        //AddBorder(sheet, book, rowIndex, dtRow.ItemArray.Length);
                        break;
                    }
                    currSerialNo = dtRow["订单号"].ToString();
                }
                sheet.SetColumnHidden(hidIndex, true);
            }
            MemoryStream ms = new MemoryStream();
            book.Write(ms);
            return ms.ToArray();
        }

        public void AddBorder(ISheet ish, IWorkbook wor, int rowindex, int len)
        {
            for (int i = 0; i < len; i++)
            {
                ICell cell = ish.GetRow(rowindex - 1).GetCell(i);
                HSSFCellStyle Style = wor.CreateCellStyle() as HSSFCellStyle;

                //Style.Alignment = HorizontalAlignment.Center;
                Style.VerticalAlignment = VerticalAlignment.Top;
                //Style.BorderTop = BorderStyle.Thin;
                //Style.BorderRight = BorderStyle.Thin;
                //Style.BorderLeft = BorderStyle.Thin;
                Style.BorderBottom = BorderStyle.Thin;
                Style.DataFormat = 0;
                cell.CellStyle = Style;
            }
        }

    }
}