﻿namespace HZ.Admin
{
    using System;

    /// <summary>
    /// 管理员  商家 登录状态Session值
    /// </summary>
    [Serializable]
    public class RuleUser
    {
        /// <summary>
        /// 后台权限ID
        /// </summary>
        public Enum_Rule nRule { get; set; }

        /// <summary>
        /// 后台登录名
        /// </summary>
        public string vcUserName { get; set; }

        public int nAdminID { get; set; }

        public RuleUser( string _username, int _adminID)
        {        
            vcUserName = _username;
            nAdminID = _adminID;
        }
    }

    /// <summary>
    /// 角色枚举
    /// </summary>
    public enum Enum_Rule
    {
        /// <summary>
        /// 管理员角色
        /// </summary>
        Administrator = 10,
        /// <summary>
        /// 店铺商家角色
        /// </summary>
        Shop = 11,
        /// <summary>
        /// 代理商角色
        /// </summary>
        Agent = 12,
        /// <summary>
        /// 初始化角色
        /// </summary>
        Init = 99
    }
}