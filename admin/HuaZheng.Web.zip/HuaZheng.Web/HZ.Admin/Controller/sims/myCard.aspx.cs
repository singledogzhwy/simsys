﻿using HZ.Admin.Controller.sim;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



namespace HZ.Admin.Controller.sims
{
    public partial class myCard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public override void VerifyRenderingInServerForm(Control control) { }
        protected void btn_excel_Click(object sender, EventArgs e)
        {
            string _sim = sim.Value.Trim();
           
            string _pkgId = pkgId.Value.Trim();
            string _cardType = cardType.Value.Trim();
            string _isOpen = isOpen.Value.Trim();
            string _isGprs = isGprs.Value.Trim();
            string _terminal = terminal.Value.Trim();

            DataTable dt = SQLHelper.ExecuteDataset(new Utils().getConnectionStr(), "HZ_cards_Excel", _sim, _pkgId, _cardType, _isOpen, _isGprs, _terminal).Tables[0];

            byte[] bts = new FinanceExcel().FinanceLog(dt, "数据记录");
            Response.AddHeader("Content-Disposition", string.Format("attachment; filename={0}.xls", "SIM卡号记录" + DateTime.Now.ToString("yyyyMMddHHmmssfff")));
            Response.BinaryWrite(bts);
        }
    }
}