﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HZ.DAL;
using HZ.Model;
using HZ.Common;
using System.Data;

namespace HZ.BLL
{
    public class order_table
    {
        order_tableDao dao = new order_tableDao();

        #region 基本方法
        /// <summary>
        /// 得到最大ID
        /// </summary>
        public int GetMaxId()
        {
            return dao.GetMaxId();
        }

        /// <summary>
        /// 是否存在该记录
        /// </summary>
        public bool Exists(int id)
        {
            return dao.Exists(id);
        }

        /// <summary>
        /// 增加一条数据
        /// </summary>
        public int Add(order_tableInfo model)
        {
            return dao.Add(model);
        }

        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(order_tableInfo model)
        {
            return dao.Update(model);
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(int id)
        {
            return dao.Delete(id);
        }

        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool DeleteList(string idlist)
        {
            return dao.DeleteList(idlist);
        }

        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public order_tableInfo GetModel(int id)
        {
            return dao.GetModel(id);
        }

        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public order_tableInfo GetModelBy(string where,string filedOrder)
        {
            return dao.GetModelBy(where,filedOrder);
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public order_tableInfo[] GetList(int top, string where, string fileOrder, out int recordCount)
        {
            return dao.DataSetToList(dao.GetList(top, where, fileOrder), false, out recordCount).ToArray();
        }


        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            return dao.GetRecordCount(strWhere);
        }

        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public order_tableInfo[] GetList(int pageIndex, int pageSize, string where, string fileOrder,out int recordCount)
        {
            return dao.DataSetToList(dao.GetList(pageIndex, pageSize, where, fileOrder), true, out recordCount).ToArray();
        }
        #endregion
    }
}
