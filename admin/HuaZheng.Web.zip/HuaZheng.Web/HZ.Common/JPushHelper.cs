﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

using JPushAPI;
using JPushAPI.common;
using JPushAPI.common.resp;
using JPushAPI.push.mode;
using JPushAPI.push.notification;
using JPushAPI.push;

namespace ZH.Common
{
    public class JPushHelper
    {
        public static String TITLE = "tttt";
        public static String ALERT = string.Empty;
        public static String MSG_CONTENT = "hehe";
        public static String REGISTRATION_ID = "0";
        public static String TAG = "0";
        public static String app_key = "5c3b38095562dfc574432960";
        public static String master_secret = "720f0d2010870a7952c46446";


        public static string GetBase64HeaderParams()
        {
            byte[] base64Str_app_key = Encoding.ASCII.GetBytes(app_key);
            byte[] base64Str_master_secret = Encoding.ASCII.GetBytes(master_secret);
            return Convert.ToBase64String(base64Str_app_key) + ":" + Convert.ToBase64String(base64Str_master_secret);
        }

        #region 推送所有
        public void PushAll(string _ALERT)
        {
            ALERT = _ALERT;
            JPushClient client = new JPushClient(app_key, master_secret);
            PushPayload payload = PushObject_All_All_Alert();
            try
            {
                MessageResult result = client.SendPush(payload);
                Log.i("JPUSH",
                        result.ResponseResult.responseContent + Environment.NewLine +
                        (result.isResultOK() ? "SUCCESS" : "FAIL")
                    );
                #region ////////////////////////

                ////由于统计数据并非非是即时的,所以等待一小段时间再执行下面的获取结果方法
                //System.Threading.Thread.Sleep(5000);
                
                ///*如需查询上次推送结果执行下面的代码*/
                //var apiResult = client.getReceivedApi(result.msg_id.ToString());
                //var apiResultv3 = client.getReceivedApi_v3(result.msg_id.ToString());

                ///*如需查询某个messageid的推送结果执行下面的代码*/
                //var queryResultWithV2 = client.getReceivedApi("1739302794");
                //var querResultWithV3 = client.getReceivedApi_v3("1739302794");
                #endregion
            }
            catch (APIRequestException e)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("从JPush服务器错误响应" + Environment.NewLine);
                sb.Append("HTTP Status: " + e.Status + Environment.NewLine);
                sb.Append("Error Code: " + e.ErrorCode + Environment.NewLine);
                sb.Append("Error Message: " + e.ErrorCode + Environment.NewLine);

                Log.e("JPUSH_ERROR", sb.ToString());
            }
            catch (APIConnectionException e)
            {
                Log.e("JPUSH_ERROR", e.Message + Environment.NewLine + e.Source);
            }
            catch (Exception e)
            {
                Log.e("JPUSH_ERROR", e.Message);
            }
        }
        #endregion


        #region 动态回复@用户消息推送

        public void PushDynamicReplyToAlias(string _title,string dynamicID,string userID, string toUserID)
        {
            ALERT = _title;
            JPushClient client = new JPushClient(app_key, master_secret);
            PushPayload pushPayload = new PushPayload();
            pushPayload.platform = Platform.android_ios();
            pushPayload.audience = Audience.s_alias(toUserID);
            pushPayload.notification = new Notification().setAlert(ALERT);
            pushPayload.notification.AndroidNotification.AddExtra("dynamicID", dynamicID).AddExtra("userID", userID);

            MessageResult result = client.SendPush(pushPayload);
        }
        #endregion


        #region Custom Push Method

        public static PushPayload PushObject_All_All_Alert()
        {
            PushPayload pushPayload = new PushPayload();
            pushPayload.platform = Platform.all();
            pushPayload.audience = Audience.all();
            pushPayload.notification = new Notification().setAlert(ALERT);
            return pushPayload;
        }

        public static PushPayload PushObject_all_alias_alert()
        {

            PushPayload pushPayload = new PushPayload();
            pushPayload.platform = Platform.android();
            pushPayload.audience = Audience.s_alias("alias1");
            pushPayload.notification = new Notification().setAlert(ALERT);
            return pushPayload;
        }

        public static PushPayload PushObject_Android_Tag_AlertWithTitle()
        {
            PushPayload pushPayload = new PushPayload();

            pushPayload.platform = Platform.android();
            pushPayload.audience = Audience.s_tag("tag1");
            pushPayload.notification = Notification.android(ALERT, TITLE);

            return pushPayload;
        }

        public static PushPayload PushObject_android_and_ios()
        {
            PushPayload pushPayload = new PushPayload();
            pushPayload.platform = Platform.android_ios();
            var audience = Audience.s_alias("tag1");
            pushPayload.audience = audience;
            var notification = new Notification().setAlert("alert content");
            notification.AndroidNotification = new AndroidNotification().setTitle("Android Title");
            notification.IosNotification = new IosNotification();
            notification.IosNotification.incrBadge(1);
            notification.IosNotification.AddExtra("extra_key", "extra_value");

            pushPayload.notification = notification.Check();


            return pushPayload;
        }

        public static PushPayload PushObject_ios_tagAnd_alertWithExtrasAndMessage()
        {
            PushPayload pushPayload = new PushPayload();
            pushPayload.platform = Platform.android_ios();
            pushPayload.audience = Audience.s_tag_and("tag1", "tag_all");
            var notification = new Notification();
            notification.IosNotification = new IosNotification().setAlert(ALERT).setBadge(5).setSound("happy").AddExtra("from", "JPush");

            pushPayload.notification = notification;
            pushPayload.message = Message.content(MSG_CONTENT);
            return pushPayload;

        }

        public static PushPayload PushObject_ios_audienceMore_messageWithExtras()
        {

            var pushPayload = new PushPayload();
            pushPayload.platform = Platform.android_ios();
            pushPayload.audience = Audience.s_tag("tag1", "tag2");
            pushPayload.message = Message.content(MSG_CONTENT).AddExtras("from", "JPush");
            return pushPayload;

        }

        #endregion


    }
}
