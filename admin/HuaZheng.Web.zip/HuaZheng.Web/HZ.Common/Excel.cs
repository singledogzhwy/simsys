﻿using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

namespace ZH.Common
{
    public class Excel
    {
        readonly int EXCEL03_MaxRow = 65535;

        /// <summary>
        /// 将DataTable转换为excel2003格式。
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public byte[] DataTable2Excel(System.Data.DataTable dt, string sheetName)
        {

            IWorkbook book = new HSSFWorkbook();
            if (dt.Rows.Count < EXCEL03_MaxRow)
                DataWrite2Sheet(dt, 0, dt.Rows.Count - 1, book, sheetName);
            else
            {
                int page = dt.Rows.Count / EXCEL03_MaxRow;
                for (int i = 0; i < page; i++)
                {
                    int start = i * EXCEL03_MaxRow;
                    int end = (i * EXCEL03_MaxRow) + EXCEL03_MaxRow - 1;
                    DataWrite2Sheet(dt, start, end, book, sheetName + i.ToString());
                }
                int lastPageItemCount = dt.Rows.Count % EXCEL03_MaxRow;
                DataWrite2Sheet(dt, dt.Rows.Count - lastPageItemCount, lastPageItemCount, book, sheetName + page.ToString());
            }
            MemoryStream ms = new MemoryStream();
            book.Write(ms);
            return ms.ToArray();
        }
        private void DataWrite2Sheet(System.Data.DataTable dt, int startRow, int endRow, IWorkbook book, string sheetName)
        {
            ISheet sheet = book.CreateSheet(sheetName);
            IRow header = sheet.CreateRow(0);
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                ICell cell = header.CreateCell(i);
                string val = dt.Columns[i].Caption ?? dt.Columns[i].ColumnName;

                cell.SetCellValue(val);
            }
            int rowIndex = 1;
            for (int i = startRow; i <= endRow; i++)
            {
                DataRow dtRow = dt.Rows[i];
                IRow excelRow = sheet.CreateRow(rowIndex++);

                for (int j = 0; j < dtRow.ItemArray.Length; j++)
                {
                    var temp = dtRow[j].ToString();
                    if (temp.Contains("br"))
                    {
                        temp = dtRow[j].ToString().Replace("br", "\r\n");
                    }
                    ICell ic = excelRow.CreateCell(j);
                    ic.SetCellValue(temp);
                }
            }
        }



        public byte[] ToExcelMutiLine(System.Data.DataTable dt, string sheetName,DateTime dtBeginTime,DateTime dtEndTime)
        {
            IWorkbook book = new HSSFWorkbook();
            if (dt.Rows.Count < EXCEL03_MaxRow)
                DataWrite2SheetCustom(dt, 0, dt.Rows.Count - 1, book, sheetName, dtBeginTime, dtEndTime);
            else
            {
                int page = dt.Rows.Count / EXCEL03_MaxRow;
                for (int i = 0; i < page; i++)
                {
                    int start = i * EXCEL03_MaxRow;
                    int end = (i * EXCEL03_MaxRow) + EXCEL03_MaxRow - 1;
                    DataWrite2SheetCustom(dt, start, end, book, sheetName + i.ToString(), dtBeginTime, dtEndTime);
                }
                int lastPageItemCount = dt.Rows.Count % EXCEL03_MaxRow;
                DataWrite2SheetCustom(dt, dt.Rows.Count - lastPageItemCount, lastPageItemCount, book, sheetName + page.ToString(), dtBeginTime, dtEndTime);
            }
            MemoryStream ms = new MemoryStream();
            book.Write(ms);
            return ms.ToArray();
        }

        private void DataWrite2SheetCustom(System.Data.DataTable dt, int startRow, int endRow, IWorkbook book, string sheetName, DateTime dtBeginTime, DateTime dtEndTime)
        {
            int rowIndex = 1;

            int hidIndex = -1;
            ISheet sheet = book.CreateSheet(sheetName);
            IRow header = sheet.CreateRow(0);

            //创建标题

            //IRow excelRow = sheet.CreateRow(rowIndex++);
            //for (int i = 0; i < dt.Columns.Count; i++)
            //{
            //    excelRow.CreateCell(i).SetCellValue(dtBeginTime.ToString("yyyy-MM-dd") + " ~ " + dtEndTime.ToString("yyyy-MM-dd"));
            //}
            //sheet.AddMergedRegion(new CellRangeAddress(1, 1, 0, dt.Columns.Count));

            IRow excelRow = null;
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                ICell cell = header.CreateCell(i);
                string val = dt.Columns[i].Caption ?? dt.Columns[i].ColumnName;

                if (val == "Count")
                {
                    cell.SetCellValue("订单总商品数量");
                    hidIndex = i;
                    continue;
                }
                else
                {
                    cell.SetCellValue(val);
                }
            }

            for (int i = startRow; i <= endRow; i++)
            {
                DataRow dtRow = dt.Rows[i];
                excelRow = null;

                var lineColuIndex = -1;
                var count1 = false;
                for (int j = 0; j < dtRow.ItemArray.Length; j++)
                {
                    var count = _Common.SafeInt(dtRow["Count"].ToString());
                    if (count > 1)
                    {
                        for (int c = 0; c < count; c++)
                        {
                            excelRow = sheet.CreateRow(rowIndex++);
                            for (int k = 0; k < dtRow.ItemArray.Length; k++)
                            {
                                var val = dtRow[k].ToString();
                                if (val.Contains("|"))
                                {
                                    lineColuIndex = k;
                                    val = val.Substring(0, val.Length - 1).Split('|')[c].ToString();
                                    excelRow.CreateCell(k).SetCellValue(val);
                                }
                                else
                                {
                                    excelRow.CreateCell(k).SetCellValue(val);
                                }

                                sheet.SetColumnWidth(k, (val.Length < 3 ? 5 : val.Length) * 550);
                                continue;
                            }
                        }
                        for (int cc = 0; cc < dtRow.ItemArray.Length; cc++)
                        {
                            if (cc != lineColuIndex)
                            {
                                sheet.AddMergedRegion(new CellRangeAddress(rowIndex - count, rowIndex - 1, cc, cc));
                            }
                        }
                        //sheet.SetColumnHidden(hidIndex, true);
                        AddBorder(sheet, book, rowIndex, dtRow.ItemArray.Length);
                        break;
                    }
                    else
                    {
                        count1 = true;
                        break;
                    }
                }

                if (count1 == true)
                {
                    excelRow = sheet.CreateRow(rowIndex++);
                    for (int j = 0; j < dtRow.ItemArray.Length; j++)
                    {
                        var val = dtRow[j].ToString();
                        if (val.Contains("|"))
                        {
                            val = val.Substring(0, val.Length - 1);
                        }
                        excelRow.CreateCell(j).SetCellValue(val);
                        sheet.SetColumnWidth(j, (val.Length < 3 ? 5 : val.Length) * 550);
                    }
                    //sheet.SetColumnHidden(hidIndex, true);
                    AddBorder(sheet, book, rowIndex, dtRow.ItemArray.Length);
                }
            }
        }

        /// <summary>
        /// 加边框
        /// </summary>
        /// <param name="rowindex">1开始</param>
        /// <param name="cellIndex">1开始</param>
        public void AddBorder(ISheet ish, IWorkbook wor, int rowindex, int len)
        {
            for (int i = 0; i < len; i++)
            {
                ICell cell = ish.GetRow(rowindex - 1).GetCell(i);
                HSSFCellStyle Style = wor.CreateCellStyle() as HSSFCellStyle;

                //Style.Alignment = HorizontalAlignment.Center;
                Style.VerticalAlignment = VerticalAlignment.Top;
                //Style.BorderTop = BorderStyle.Thin;
                //Style.BorderRight = BorderStyle.Thin;
                //Style.BorderLeft = BorderStyle.Thin;
                Style.BorderBottom = BorderStyle.Thin;
                Style.DataFormat = 0;
                cell.CellStyle = Style;
            }
        }

    }
}
