﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Yunpian.conf;
using Yunpian.model;
using Yunpian.lib;
using System.Web;
namespace ZH.Common
{
    public class SMS
    {
        /// <summary>
        /// 发送验证码
        /// </summary>
        /// <param name="tel">电话</param>
        /// <returns>验证码</returns>
        public static string SendCode(string tel)
        {
            //设置apikey
            Config config = new Config("3c0e2fe3dbd8321207c52a5842ceda40");
            Dictionary<string, string> data = new Dictionary<string, string>();
            Result result = null;
            // 发送单条短信
            SmsOperator sms = new SmsOperator(config);
            data.Clear();
            data.Add("mobile", tel);
            Random ran = new Random();
            string code = ran.Next(1000, 9999).ToString();
            data.Add("text", "【惠惠正品】验证码为" + code + "，请在页面中输入以完成验证。");
            result = sms.singleSend(data);
           
            if (result.responseText.Contains("成功"))
                return code;
            else
                return result.ToString();
        }
    }
}
