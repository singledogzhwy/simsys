﻿using System;
using System.IO;
using System.Threading;
using Aliyun.OSS.Common;
using System.Text;
using Aliyun.OSS.Util;
using Aliyun.OSS;
using System.Web;
using System.Drawing.Imaging;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace ZH.Common
{
    public static class ImageUploadToOSS
    {

        private static string accessKeyId = "LTAIvQeaHRhkIH62";
        private static string accessKeySecret = "yXG4PlYaPTqPltjQHVEwplk7CCnCI3";
        private static string endpoint = "http://img.cszhenghui.com";

        static string bucketName = "zhenghuiphoto";




        /// <summary>
        /// 图片压缩成base64 之后再上传
        /// </summary>
        /// <param name="putStr"> 图片压缩后获得的base64 字符 </param>
        /// <param name="key">云文件保存的文件夹路径</param>
        public static string PutObjectFromString(string putStr,string type)
        {
            //System.Net.ServicePointManager.Expect100Continue = false;
            ClientConfiguration conf = new ClientConfiguration();
            conf.IsCname = true;

            OssClient client = new OssClient(endpoint, accessKeyId, accessKeySecret, conf);
            string guid = Guid.NewGuid().ToString();
            try
            {
                int delLength = putStr.IndexOf(',') + 1;
                string str = putStr.Substring(delLength, putStr.Length - delLength);
                byte[] binaryData = Convert.FromBase64String(str);
                MemoryStream stream = new MemoryStream(binaryData);
                client.PutObject(bucketName, "upload/" + type + "/source/" + guid + ".jpg", stream);
                return "/upload/" + type + "/source/" + guid + ".jpg";
            }
            catch (Exception)
            {
                return "error";
                throw;
            }
            
        }

        /// <summary>
        /// 上传指定文件
        /// </summary>
        public static string PutObjectFromFileWithIndx(string type, int index)
        {
            ClientConfiguration conf = new ClientConfiguration();
            conf.IsCname = true;

            OssClient client = new OssClient(endpoint, accessKeyId, accessKeySecret, conf);
            try
            {
                string guid = Guid.NewGuid().ToString();
                var stream = HttpContext.Current.Request.Files[index].InputStream;
                client.PutObject(bucketName, "upload/" + type + "/source/" + guid + ".jpg", stream);

                //压缩
                //ImageHelper.GetPicThumbnail()

                return "/upload/" + type + "/source/" + guid + ".jpg";
            }
            catch (Exception)
            {
                return "error";
                throw;
            }
        }
        
        /// <summary>
        /// 文件上传
        /// </summary>
        /// <param name="key">文件路径上传</param>
        /// <param name="isCompression">是否需要压缩上传</param>
        /// <returns></returns>
        public static string PutObjectFromFile(string type, bool isSingle)
        {
            //System.Net.ServicePointManager.Expect100Continue = false;
            ClientConfiguration conf = new ClientConfiguration();
            conf.IsCname = true;


            OssClient client = new OssClient(endpoint, accessKeyId, accessKeySecret, conf); 
            try
            {
                HttpFileCollection files = null;
                string imgUrlArray = string.Empty;
                if ((files = HttpContext.Current.Request.Files).Count > 0)
                {
                    if (isSingle)
                    {
                        string guid = Guid.NewGuid().ToString();
                        var stream = HttpContext.Current.Request.Files[0].InputStream;
                        client.PutObject(bucketName, "upload/" + type + "/source/" + guid + ".jpg", stream);
                        imgUrlArray += "/upload/" + type + "/source/" + guid + ".jpg";
                    }
                    else
                    {
                        for (int i = 0; i < files.Count; i++)
                        {
                            string guid = Guid.NewGuid().ToString();
                            var stream = HttpContext.Current.Request.Files[i].InputStream;
                            client.PutObject(bucketName, "upload/" + type + "/source/" + guid + ".jpg", stream);
                            imgUrlArray += "/upload/" + type + "/source/" + guid + ".jpg|";
                            Thread.Sleep(100);
                        }
                    }
                }
                return files.Count > 1 ? imgUrlArray.Substring(0, imgUrlArray.Length - 1) : imgUrlArray;
            }
            catch (Exception)
            {
                return "error";
                throw;
            }
            
        }

        /// <summary>
        /// 添加轮播图
        /// </summary>
        /// <param name="type"></param>
        /// <param name="startIndex"></param>
        /// <returns></returns>
        public static string PutObjectSliderImage(string type, int startIndex)
        {
            ClientConfiguration conf = new ClientConfiguration();
            conf.IsCname = true;
            OssClient client = new OssClient(endpoint, accessKeyId, accessKeySecret, conf);
            try
            {
                HttpFileCollection files = null;
                string imgUrlArray = string.Empty;
                if ((files = HttpContext.Current.Request.Files).Count > 1)
                {
                    for (int i = startIndex; i < files.Count; i++)
                    {
                        string guid = Guid.NewGuid().ToString();
                        var stream = HttpContext.Current.Request.Files[i].InputStream;
                        client.PutObject(bucketName, "upload/" + type + "/source/" + guid + ".jpg", stream);
                        imgUrlArray += "/upload/" + type + "/source/" + guid + ".jpg|";
                        Thread.Sleep(100);
                    }
                    return imgUrlArray.Substring(0, imgUrlArray.Length - 1);
                }else
	            {
                    return "";
	            }
                
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        public static string PutObjectWithStream(string type, Stream stream,string openId)
        {
            ClientConfiguration conf = new ClientConfiguration();
            conf.IsCname = true;
            OssClient client = new OssClient(endpoint, accessKeyId, accessKeySecret, conf);
            try
            {
                client.PutObject(bucketName, "upload/" + type + "/source/" + openId + ".jpg", stream);
                return "/upload/" + type + "/source/" + openId + ".jpg";
            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// 无损压缩图片
        /// </summary>
        /// <param name="sFile">原图片</param>
        /// <param name="dFile">压缩后保存位置</param>
        /// <param name="dHeight">高度</param>
        /// <param name="dWidth">宽度</param>
        /// <param name="flag">压缩质量 1-100</param>
        /// <returns></returns>

        public static bool GetPicThumbnail(string sFile, string dFile, double dHeight_bfb, double dWidth_bfb,
            int flag)
        {
            System.Drawing.Image iSource = System.Drawing.Image.FromFile(sFile);
            ImageFormat tFormat = iSource.RawFormat;
            int sW = 0, sH = 0;

            //按比例缩放
            Size tem_size = new Size(iSource.Width, iSource.Height);


            int dHeight = Convert.ToInt32(tem_size.Height * dHeight_bfb);
            int dWidth = Convert.ToInt32(tem_size.Width * dWidth_bfb);

            if (tem_size.Width > dHeight || tem_size.Width > dWidth) //将**改成c#中的或者操作符号
            {

                if ((tem_size.Width * dHeight) > (tem_size.Height * dWidth))
                {
                    sW = dWidth;
                    sH = (dWidth * tem_size.Height) / tem_size.Width;
                }

                else
                {
                    sH = dHeight;
                    sW = (tem_size.Width * dHeight) / tem_size.Height;
                }
            }
            else
            {
                sW = tem_size.Width;
                sH = tem_size.Height;
            }


            Bitmap ob = new Bitmap(dWidth, dHeight);

            Graphics g = Graphics.FromImage(ob);

            g.Clear(System.Drawing.Color.WhiteSmoke);

            g.CompositingQuality = CompositingQuality.HighQuality;

            g.SmoothingMode = SmoothingMode.HighQuality;

            g.InterpolationMode = InterpolationMode.HighQualityBicubic;

            g.DrawImage(iSource, new Rectangle((dWidth - sW) / 2, (dHeight - sH) / 2, sW, sH), 0, 0, iSource.Width, iSource.Height, GraphicsUnit.Pixel);

            g.Dispose();

            //以下代码为保存图片时，设置压缩质量

            EncoderParameters ep = new EncoderParameters();

            long[] qy = new long[1];

            qy[0] = flag; //设置压缩的比例1-100

            EncoderParameter eParam = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, qy);

            ep.Param[0] = eParam;

            try
            {

                ImageCodecInfo[] arrayICI = ImageCodecInfo.GetImageEncoders();

                ImageCodecInfo jpegICIinfo = null;

                for (int x = 0; x < arrayICI.Length; x++)
                {

                    if (arrayICI[x].FormatDescription.Equals("JPEG"))
                    {

                        jpegICIinfo = arrayICI[x];

                        break;

                    }

                }

                if (jpegICIinfo != null)
                {

                    ob.Save(dFile, jpegICIinfo, ep);//dFile是压缩后的新路径

                }

                else
                {

                    ob.Save(dFile, tFormat);

                }

                return true;

            }

            catch
            {

                return false;

            }

            finally
            {

                iSource.Dispose();

                ob.Dispose();

            }

        }
        
    }
}
