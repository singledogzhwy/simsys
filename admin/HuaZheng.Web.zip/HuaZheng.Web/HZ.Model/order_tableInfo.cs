﻿/**  
* order_tableInfo.cs
*
* 功 能： N/A
* 类 名： order_tableInfo
*
* Ver    变更日期             负责人  变更内容
* ───────────────────────────────────
* V0.01  2014/2/1 14:35:14   N/A    初版
*
* Copyright (c)  Corporation. All rights reserved.
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：　　　　　　　　　　　　　　│
*└──────────────────────────────────┘
*/
using System;
using System.Runtime.Serialization;
namespace HZ.Model
{
	/// <summary>
	/// order_tableInfo:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[DataContract]
	public partial class order_tableInfo
	{
		public order_tableInfo()
		{
             orderId = "";
             sim = 0;
             iccid = "";
             cardType = "";
             pkgId = 0;
             prepackageid = 0;
             userId = "";
             price = 0.0f;
             rnwStatus = false;
             failReason = "";
             rnwTime = DateTime.Now;
             orderType = 0;
             ThrdOrderid = "";
             mchid = "";
             rcvName = "";
             payName = "";
             accessName = "";

        }
		#region Model

	    /// <summary>
 		/// 订单号 
 		/// </summary>
 		[DataMember]
         public string orderId { get; set; }

	    /// <summary>
 		/// sim卡号 
 		/// </summary>
 		[DataMember]
         public long sim { get; set; }

	    /// <summary>
 		/// iccid号 
 		/// </summary>
 		[DataMember]
         public string iccid { get; set; }

	    /// <summary>
 		/// 卡源 
 		/// </summary>
 		[DataMember]
         public string cardType { get; set; }

	    /// <summary>
 		/// 使用的套餐编号 
 		/// </summary>
 		[DataMember]
         public int pkgId { get; set; }

	    /// <summary>
 		/// 充值之前使用的上个套餐编号 
 		/// </summary>
 		[DataMember]
         public int prepackageid { get; set; }

	    /// <summary>
 		/// 所属用户编号 
 		/// </summary>
 		[DataMember]
         public string userId { get; set; }

	    /// <summary>
 		/// 要续费的套餐价格 
 		/// </summary>
 		[DataMember]
         public Double price { get; set; }

	    /// <summary>
 		/// 本次订单成功失败？0失败，1成功 
 		/// </summary>
 		[DataMember]
         public bool rnwStatus { get; set; }

	    /// <summary>
 		/// 失败原因 
 		/// </summary>
 		[DataMember]
         public string failReason { get; set; }

	    /// <summary>
 		/// 订单生成时间 
 		/// </summary>
 		[DataMember]
         public DateTime rnwTime { get; set; }

	    /// <summary>
 		/// 标记如何生成，1微信生成，2api接口生成 
 		/// </summary>
 		[DataMember]
         public int orderType { get; set; }

	    /// <summary>
 		/// 接口生成时有效，第三方自定义订单id 
 		/// </summary>
 		[DataMember]
         public string ThrdOrderid { get; set; }

	    /// <summary>
 		/// 微信生成时有效，微信支付商户id 
 		/// </summary>
 		[DataMember]
         public string mchid { get; set; }

	    /// <summary>
 		/// 收款方名称 
 		/// </summary>
 		[DataMember]
         public string rcvName { get; set; }

	    /// <summary>
 		/// 付款方名称 
 		/// </summary>
 		[DataMember]
         public string payName { get; set; }

	    /// <summary>
 		/// 标志字段，标志使用pageapi的下级经销商。本公司的标记字段为huaz。 
 		/// </summary>
 		[DataMember]
         public string accessName { get; set; }


		#endregion Model

	}
}

