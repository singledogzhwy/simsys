﻿/**  
* card_tableInfo.cs
*
* 功 能： N/A
* 类 名： card_tableInfo
*
* Ver    变更日期             负责人  变更内容
* ───────────────────────────────────
* V0.01  2014/2/1 14:35:14   N/A    初版
*
* Copyright (c)  Corporation. All rights reserved.
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：　　　　　　　　　　　　　　│
*└──────────────────────────────────┘
*/
using System;
using System.Runtime.Serialization;
namespace HZ.Model
{
	/// <summary>
	/// card_tableInfo:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[DataContract]
	public partial class card_tableInfo
	{
		public card_tableInfo()
		{
             sim = 0;
             ICCID = "";
             userId = 0;
             pkgId = 0;
             initialPeriod = "";
             initialValue = "";
             balance = 0.0f;
             spsFlow = 0.0f;
             isOpen = false;
             isRunsout = false;
             isActive = false;
             getcardTime = DateTime.Now;
             soldTime = DateTime.Now;
             activateTime = DateTime.Now;
             expireTime = DateTime.Now;
             manualStoptime = DateTime.Now;
             manualStarttime = DateTime.Now;
             lastactivateTime = DateTime.Now;
             isGprs = false;
             isMessage = false;
             cardType = 0;
             isRealname = false;
             terminal = "";
             destory = false;

        }
		#region Model

	    /// <summary>
 		/// SIM卡号 
 		/// </summary>
 		[DataMember]
         public int sim { get; set; }

	    /// <summary>
 		/// iccid号 
 		/// </summary>
 		[DataMember]
         public string ICCID { get; set; }

	    /// <summary>
 		/// 用户的数字ID 
 		/// </summary>
 		[DataMember]
         public int userId { get; set; }

	    /// <summary>
 		/// 卡正在使用套餐的数字id 
 		/// </summary>
 		[DataMember]
         public int pkgId { get; set; }

	    /// <summary>
 		/// 初始套餐（通常为5元30m，3元10m）的周期 
 		/// </summary>
 		[DataMember]
         public string initialPeriod { get; set; }

	    /// <summary>
 		/// 对4G卡没用，2G卡结合初始套餐看周期。 
 		/// </summary>
 		[DataMember]
         public string initialValue { get; set; }

	    /// <summary>
 		/// 余额，对2G卡有效 
 		/// </summary>
 		[DataMember]
         public Double balance { get; set; }

	    /// <summary>
 		/// 剩余流量 
 		/// </summary>
 		[DataMember]
         public Double spsFlow { get; set; }

	    /// <summary>
 		/// 卡片停开机，0停机，1开机 
 		/// </summary>
 		[DataMember]
         public bool isOpen { get; set; }

	    /// <summary>
 		/// 是否因欠费停机，0否，1是 
 		/// </summary>
 		[DataMember]
         public bool isRunsout { get; set; }

	    /// <summary>
 		/// 是否从沉默期中激活 
 		/// </summary>
 		[DataMember]
         public bool isActive { get; set; }

	    /// <summary>
 		/// 从移动拿卡的时间 
 		/// </summary>
 		[DataMember]
         public DateTime getcardTime { get; set; }

	    /// <summary>
 		/// 出库（卖出）日期 
 		/// </summary>
 		[DataMember]
         public DateTime soldTime { get; set; }

	    /// <summary>
 		/// 卡片激活时间 
 		/// </summary>
 		[DataMember]
         public DateTime activateTime { get; set; }

	    /// <summary>
 		/// 到期日期，对2G卡有用。 
 		/// </summary>
 		[DataMember]
         public DateTime expireTime { get; set; }

	    /// <summary>
 		/// 做手动停机的时间 
 		/// </summary>
 		[DataMember]
         public DateTime manualStoptime { get; set; }

	    /// <summary>
 		/// 做手动开机的时间 
 		/// </summary>
 		[DataMember]
         public DateTime manualStarttime { get; set; }

	    /// <summary>
 		/// 最晚激活时间（自动激活时间） 
 		/// </summary>
 		[DataMember]
         public DateTime lastactivateTime { get; set; }

	    /// <summary>
 		/// GPRS（网络）启用中？0否，1是 
 		/// </summary>
 		[DataMember]
         public bool isGprs { get; set; }

	    /// <summary>
 		/// 有无短信功能，0否1是 
 		/// </summary>
 		[DataMember]
         public bool isMessage { get; set; }

	    /// <summary>
 		/// 卡源 
 		/// </summary>
 		[DataMember]
         public int cardType { get; set; }

	    /// <summary>
 		/// 是否实名，0否1是 
 		/// </summary>
 		[DataMember]
         public bool isRealname { get; set; }

	    /// <summary>
 		/// 使用卡片的终端类型（手机，gps，MIFI等等） 
 		/// </summary>
 		[DataMember]
         public string terminal { get; set; }

	    /// <summary>
 		/// 是否报废 
 		/// </summary>
 		[DataMember]
         public bool destory { get; set; }


		#endregion Model

	}
}

