﻿/**  
* user_tableInfo.cs
*
* 功 能： N/A
* 类 名： user_tableInfo
*
* Ver    变更日期             负责人  变更内容
* ───────────────────────────────────
* V0.01  2014/2/1 14:35:14   N/A    初版
*
* Copyright (c)  Corporation. All rights reserved.
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：　　　　　　　　　　　　　　│
*└──────────────────────────────────┘
*/
using System;
using System.Runtime.Serialization;
namespace HZ.Model
{
	/// <summary>
	/// user_tableInfo:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[DataContract]
	public partial class user_tableInfo
	{
		public user_tableInfo()
		{
             userID = 0;
             userName = "";
             showName = "";
             userPwd = "";
             userType = 0;
             sprUserid = 0;
             isApi = false;
             cardrnwSum = 0;
             cardSum = 0;
             realHierarchy = 0;
             userAddress = "";
             contacts = "";
             phone = "";
             createTime = DateTime.Now;
             isRealname = false;

        }
		#region Model

	    /// <summary>
 		/// 用户id 
 		/// </summary>
 		[DataMember]
         public int userID { get; set; }

	    /// <summary>
 		/// 登录时使用的账号 
 		/// </summary>
 		[DataMember]
         public string userName { get; set; }

	    /// <summary>
 		/// 显示的客户名字（汉字），可重复 
 		/// </summary>
 		[DataMember]
         public string showName { get; set; }

	    /// <summary>
 		/// 登录密码 
 		/// </summary>
 		[DataMember]
         public string userPwd { get; set; }

	    /// <summary>
 		/// 用户类型 
 		/// </summary>
 		[DataMember]
         public int userType { get; set; }

	    /// <summary>
 		/// 上级用户id（树形结构） 
 		/// </summary>
 		[DataMember]
         public int sprUserid { get; set; }


        /// <summary>
        /// 实名等级(1个人实名0企业实名) 
        /// </summary>
        [DataMember]
        public int realHierarchy { get; set; }

	    /// <summary>
 		/// 有无开放api？ 
 		/// </summary>
 		[DataMember]
         public bool isApi { get; set; }

	    /// <summary>
 		/// 总共续费过的卡数 
 		/// </summary>
 		[DataMember]
         public int cardrnwSum { get; set; }

	    /// <summary>
 		/// 名下总卡数 
 		/// </summary>
 		[DataMember]
         public int cardSum { get; set; }

	    /// <summary>
 		/// 联系人地址 
 		/// </summary>
 		[DataMember]
         public string userAddress { get; set; }

	    /// <summary>
 		/// 联系人名称 
 		/// </summary>
 		[DataMember]
         public string contacts { get; set; }

	    /// <summary>
 		/// 联系人电话 
 		/// </summary>
 		[DataMember]
         public string phone { get; set; }

	    /// <summary>
 		/// 创建用户时间 
 		/// </summary>
 		[DataMember]
         public DateTime createTime { get; set; }

	    /// <summary>
 		/// 是否实名 
 		/// </summary>
 		[DataMember]
         public bool isRealname { get; set; }


		#endregion Model

	}
}

