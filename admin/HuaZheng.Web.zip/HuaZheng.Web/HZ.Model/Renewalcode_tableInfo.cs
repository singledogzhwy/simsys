﻿/**  
* Renewalcode_tableInfo.cs
*
* 功 能： N/A
* 类 名： Renewalcode_tableInfo
*
* Ver    变更日期             负责人  变更内容
* ───────────────────────────────────
* V0.01  2014/2/1 14:35:14   N/A    初版
*
* Copyright (c)  Corporation. All rights reserved.
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：　　　　　　　　　　　　　　│
*└──────────────────────────────────┘
*/
using System;
using System.Runtime.Serialization;
namespace HZ.Model
{
	/// <summary>
	/// Renewalcode_tableInfo:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[DataContract]
	public partial class Renewalcode_tableInfo
	{
		public Renewalcode_tableInfo()
		{
             rnwCode = "";
             userId = 0;
             pkgId = 0;
             codeCount = 0;
             crtTime = DateTime.Now;
             useTime = DateTime.Now;

        }
		#region Model

	    /// <summary>
 		/// 充值码值，复杂，自动生成 
 		/// </summary>
 		[DataMember]
         public string rnwCode { get; set; }

	    /// <summary>
 		/// 所属用户id 
 		/// </summary>
 		[DataMember]
         public int userId { get; set; }

	    /// <summary>
 		/// 对应的套餐id 
 		/// </summary>
 		[DataMember]
         public int pkgId { get; set; }

	    /// <summary>
 		/// 同类充值码总个数 
 		/// </summary>
 		[DataMember]
         public int codeCount { get; set; }

	    /// <summary>
 		/// 创建时间 
 		/// </summary>
 		[DataMember]
         public DateTime crtTime { get; set; }

	    /// <summary>
 		/// 最近充值时间 
 		/// </summary>
 		[DataMember]
         public DateTime useTime { get; set; }


		#endregion Model

	}
}

