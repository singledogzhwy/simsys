﻿/**  
* package_tableInfo.cs
*
* 功 能： N/A
* 类 名： package_tableInfo
*
* Ver    变更日期             负责人  变更内容
* ───────────────────────────────────
* V0.01  2014/2/1 14:35:14   N/A    初版
*
* Copyright (c)  Corporation. All rights reserved.
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：　　　　　　　　　　　　　　│
*└──────────────────────────────────┘
*/
using System;
using System.Runtime.Serialization;
namespace HZ.Model
{
	/// <summary>
	/// package_tableInfo:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[DataContract]
	public partial class package_tableInfo
	{
		public package_tableInfo()
		{
             userId = 0;
             pkgId = 0;
             pkgName = "";
             Price = 0.0f;
             allowance = 0.0f;
             hasUnitprice = false;
             totalUsage = 0;
             period = 0;

        }
		#region Model

	    /// <summary>
 		/// 所属用户id 
 		/// </summary>
 		[DataMember]
         public int userId { get; set; }

	    /// <summary>
 		/// 本套餐编号 
 		/// </summary>
 		[DataMember]
         public int pkgId { get; set; }

	    /// <summary>
 		/// 本套餐名称 
 		/// </summary>
 		[DataMember]
         public string pkgName { get; set; }

	    /// <summary>
 		/// 本套餐微信续费/接口续费的价格 
 		/// </summary>
 		[DataMember]
         public Double Price { get; set; }

	    /// <summary>
 		/// 购买本套餐后的返利，用来掩盖真实价格。 
 		/// </summary>
 		[DataMember]
         public Double allowance { get; set; }

	    /// <summary>
 		/// 是否显示每G流量单价 
 		/// </summary>
 		[DataMember]
         public bool hasUnitprice { get; set; }

	    /// <summary>
 		/// 套餐内含总流量，单位KB 
 		/// </summary>
 		[DataMember]
         public int totalUsage { get; set; }

	    /// <summary>
 		/// 套餐时限，单位天。月包的套餐按自然月结算，没有固定天数。 
 		/// </summary>
 		[DataMember]
         public int period { get; set; }


		#endregion Model

	}
}

