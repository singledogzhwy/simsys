﻿/**  版本信息模板在安装目录下，可自行修改。
* user_tableDao.cs
*
* 功 能： N/A
* 类 名： user_tableDao
*
* Ver    变更日期             负责人  变更内容
* ───────────────────────────────────
* V0.01  2014/2/1 14:33:28   N/A    初版
*
* Copyright (c) 2012 Maticsoft Corporation. All rights reserved.
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：　　　　　　　　　　　　　　│
*└──────────────────────────────────┘
*/
using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Reflection;
using HZ.Model;
using HZ.DBUtility;
using HZ.DAL;


namespace HZ.DAL
{
	/// <summary>
	/// 数据访问类:user_table
	/// </summary>
	public partial class user_tableDao
	{
		public user_tableDao()
		{}
		
        #region  基础方法======

		/// <summary>
		/// 得到最大ID
		/// </summary>
		public int GetMaxId()
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select top 1 userID from user_table order by userID desc");
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
                return 0;
            else
                return Convert.ToInt32(obj);
		}

		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(int userID)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from user_table");
            strSql.Append(" where [userID]=@userID");
            SqlParameter[] parameters = {
                            new SqlParameter("@userID",SqlDbType.Int)};

            parameters[0].Value = userID;
            return DbHelperSQL.Exists(strSql.ToString(), parameters);
		}


		/// <summary>
		/// 增加一条数据
		/// </summary>
		public int Add(user_tableInfo model)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into user_table");
            strSql.Append("([userName],[showName],[userPwd],[userType],[sprUserid],[isApi],[cardrnwSum],[cardSum],[userAddress],[contacts],[phone],[createTime],[isRealname],[realHierarchy])");
            strSql.Append(" values ");
            strSql.Append("(@userName,@showName,@userPwd,@userType,@sprUserid,@isApi,@cardrnwSum,@cardSum,@userAddress,@contacts,@phone,@createTime,@isRealname，@realHierarchy);");
            strSql.Append("select @@identity");
            SqlParameter[] parameters = {
                    new SqlParameter("@userName",SqlDbType.VarChar),
                    new SqlParameter("@showName",SqlDbType.VarChar),
                    new SqlParameter("@userPwd",SqlDbType.VarChar),
                    new SqlParameter("@userType",SqlDbType.Int),
                    new SqlParameter("@sprUserid",SqlDbType.Int),
                    new SqlParameter("@isApi",SqlDbType.Bit),
                    new SqlParameter("@cardrnwSum",SqlDbType.Int),
                    new SqlParameter("@cardSum",SqlDbType.Int),
                    new SqlParameter("@userAddress",SqlDbType.VarChar),
                    new SqlParameter("@contacts",SqlDbType.VarChar),
                    new SqlParameter("@phone",SqlDbType.VarChar),
                    new SqlParameter("@createTime",SqlDbType.DateTime),
                    new SqlParameter("@isRealname",SqlDbType.Bit),
                    new SqlParameter("@realHierarchy",SqlDbType.Int)};
            
            parameters[0].Value = model.userName;
            parameters[1].Value = model.showName;
            parameters[2].Value = model.userPwd;
            parameters[3].Value = model.userType;
            parameters[4].Value = model.sprUserid;
            parameters[5].Value = model.isApi;
            parameters[6].Value = model.cardrnwSum;
            parameters[7].Value = model.cardSum;
            parameters[8].Value = model.userAddress;
            parameters[9].Value = model.contacts;
            parameters[10].Value = model.phone;
            parameters[11].Value = model.createTime;
            parameters[12].Value = model.isRealname;
            parameters[12].Value = model.realHierarchy;

            object obj = DbHelperSQL.GetSingle(strSql.ToString(), parameters);
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(user_tableInfo model)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("UPDATE [user_table] SET ");
            strSql.Append("[userName] = @userName,");
            strSql.Append("[showName] = @showName,");
            strSql.Append("[userPwd] = @userPwd,");
            strSql.Append("[userType] = @userType,");
            strSql.Append("[sprUserid] = @sprUserid,");
            strSql.Append("[isApi] = @isApi,");
            strSql.Append("[cardrnwSum] = @cardrnwSum,");
            strSql.Append("[cardSum] = @cardSum,");
            strSql.Append("[userAddress] = @userAddress,");
            strSql.Append("[contacts] = @contacts,");
            strSql.Append("[phone] = @phone,");
            strSql.Append("[createTime] = @createTime,");
            strSql.Append("[isRealname] = @isRealname ");
            strSql.Append("[realHierarchy] = @realHierarchy ");
            strSql.Append(" where [userID]=@userID");

            SqlParameter[] parameters = {
                    new SqlParameter("@userID",SqlDbType.Int),
                    new SqlParameter("@userName",SqlDbType.VarChar),
                    new SqlParameter("@showName",SqlDbType.VarChar),
                    new SqlParameter("@userPwd",SqlDbType.VarChar),
                    new SqlParameter("@userType",SqlDbType.Int),
                    new SqlParameter("@sprUserid",SqlDbType.Int),
                    new SqlParameter("@isApi",SqlDbType.Bit),
                    new SqlParameter("@cardrnwSum",SqlDbType.Int),
                    new SqlParameter("@cardSum",SqlDbType.Int),
                    new SqlParameter("@userAddress",SqlDbType.VarChar),
                    new SqlParameter("@contacts",SqlDbType.VarChar),
                    new SqlParameter("@phone",SqlDbType.VarChar),
                    new SqlParameter("@createTime",SqlDbType.DateTime),
                    new SqlParameter("@isRealname",SqlDbType.Bit),
                    new SqlParameter("@realHierarchy",SqlDbType.Int)};

            parameters[0].Value = model.userID;
            parameters[1].Value = model.userName;
            parameters[2].Value = model.showName;
            parameters[3].Value = model.userPwd;
            parameters[4].Value = model.userType;
            parameters[5].Value = model.sprUserid;
            parameters[6].Value = model.isApi;
            parameters[7].Value = model.cardrnwSum;
            parameters[8].Value = model.cardSum;
            parameters[9].Value = model.userAddress;
            parameters[10].Value = model.contacts;
            parameters[11].Value = model.phone;
            parameters[12].Value = model.createTime;
            parameters[13].Value = model.isRealname;
            parameters[13].Value = model.realHierarchy;

            int rows = DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
            
		}

        /// <summary>
        /// DataSet转List
        /// </summary>
        public List<user_tableInfo> DataSetToList(DataSet ds,bool isPaging, out int recordCount)
        {
            List<user_tableInfo> list = new List<user_tableInfo>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                list.Add(DataRowToModel(row));
            }
            if (isPaging)
            {
                recordCount = Convert.ToInt32(ds.Tables[1].Rows[0]["recordCount"]);
            }
            else
            {
                recordCount = 0;
            }
            return list;
        }

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(int userID)
		{

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from user_table ");
            strSql.Append("where [userID]=@userID");
            SqlParameter[] parameters = {
					new SqlParameter("@userID", SqlDbType.Int)};
            parameters[0].Value = userID;

            int rows = DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }            
		}

        /// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ");
            if (Top > 0)
            {
                strSql.Append(" top " + Top.ToString());
            }
            strSql.Append("  * FROM user_table");

            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }

            if(filedOrder.Trim() != "")
            {
                strSql.Append(" order by " + filedOrder);
            }
            
            return DbHelperSQL.Query(strSql.ToString());
		}

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select * FROM user_table");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }

            return Convert.ToInt32(DbHelperSQL.GetSingle(PagingHelper.CreateCountingSql(strSql.ToString())));
         
        }

        /// <summary>
        /// 分页数据
        /// </summary>
        public DataSet GetList(int pageIndex, int pageSize, string strWhere, string filedOrder)
		{
            StringBuilder strSql = new StringBuilder();
            
            //这里拼接单表或者多表都可以
            strSql.Append("select * FROM user_table"); 
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperSQL.Query(PagingHelper.CreatePagingSql(pageIndex, pageSize, strSql.ToString(), filedOrder));

		}

		/// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string newsidlist )
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from user_table ");
            strSql.Append("where [userID]  in (" + newsidlist + ")");
            int rows = DbHelperSQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public user_tableInfo GetModel(int userID)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select top 1 * from user_table ");
            strSql.Append("where [userID]=@userID");

            user_tableInfo model=new user_tableInfo();

            SqlParameter[] parameters = {
					new SqlParameter("@userID", SqlDbType.Int,4)};
            parameters[0].Value = userID;

            DataSet ds = DbHelperSQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
		}

        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public user_tableInfo GetModelBy(string where,string filedOrder)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select top 1 * from user_table ");
            if (!string.IsNullOrEmpty(where))
            {
                strSql.Append(" where " + where);
            }
            if (!string.IsNullOrEmpty(filedOrder))
            {
                strSql.Append(" order by " + filedOrder);
            }

            DataSet ds = DbHelperSQL.Query(strSql.ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }
        
        #endregion  

        #region 私有方法======
		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		/// <summary>
        /// DataRow 转为实体类
        /// </summary>
        private user_tableInfo DataRowToModel(DataRow row)
        {
            user_tableInfo model = new user_tableInfo();
            if (row != null)
            {
                if (row["userID"] != null && row["userID"].ToString() != "")
                {
                    model.userID = int.Parse(row["userID"].ToString());
                }

                if (row["userName"] != null)
                {
                    model.userName = row["userName"].ToString();
                }
                if (row["showName"] != null)
                {
                    model.showName = row["showName"].ToString();
                }

                if (row["userPwd"] != null)
                {
                    model.userPwd = row["userPwd"].ToString();
                }

                if (row["userType"] != null && row["userType"].ToString() != "")
                {
                    model.userType = int.Parse(row["userType"].ToString());
                }

                if (row["sprUserid"] != null && row["sprUserid"].ToString() != "")
                {
                    model.sprUserid = int.Parse(row["sprUserid"].ToString());
                }

                if (row["isApi"] != null && row["isApi"].ToString() != "")
                {
                    if ((row["isApi"].ToString() == "1") || (row["isApi"].ToString().ToLower() == "true"))
                    {
                        model.isApi = true;
                    }
                    else
                    {
                        model.isApi = false;
                    }
                }
                
            
                if (row["cardrnwSum"] != null && row["cardrnwSum"].ToString() != "")
                    {
                        model.cardrnwSum = int.Parse(row["cardrnwSum"].ToString());
                    }

                 if (row["cardSum"] != null && row["cardSum"].ToString() != "")
                {
                    model.cardSum = int.Parse(row["cardSum"].ToString());
                }

                 if (row["userAddress"] != null)
                 {
                     model.userAddress = row["userAddress"].ToString();
                 }

                 if (row["contacts"] != null)
                 {
                     model.contacts = row["contacts"].ToString();
                 }

                 if (row["phone"] != null)
                 {
                     model.showName = row["phone"].ToString();
                 }



                 if (row["createTime"] != null && row["createTime"].ToString() != "")
                {
                    model.createTime = DateTime.Parse(row["createTime"].ToString());
                }



                if (row["isRealname"] != null && row["isRealname"].ToString() != "")
                {
                    if ((row["isRealname"].ToString() == "1") || (row["isRealname"].ToString().ToLower() == "true"))
                    {
                        model.isRealname = true;
                    }
                    else
                    {
                        model.isRealname = false;
                    }
                }

             

                if (row["realHierarchy"] != null && row["realHierarchy"].ToString() != "")
                {
                    model.realHierarchy = int.Parse(row["realHierarchy"].ToString());
                }

             
        
            }
            return model;
        }

		#endregion  BasicMethod


   
    }
}

