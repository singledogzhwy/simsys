﻿/**  版本信息模板在安装目录下，可自行修改。
* Renewalcode_tableDao.cs
*
* 功 能： N/A
* 类 名： Renewalcode_tableDao
*
* Ver    变更日期             负责人  变更内容
* ───────────────────────────────────
* V0.01  2014/2/1 14:33:28   N/A    初版
*
* Copyright (c) 2012 Maticsoft Corporation. All rights reserved.
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：　　　　　　　　　　　　　　│
*└──────────────────────────────────┘
*/
using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Reflection;
using HZ.Model;
using HZ.DBUtility;
using HZ.DAL;


namespace HZ.DAL
{
	/// <summary>
	/// 数据访问类:Renewalcode_table
	/// </summary>
	public partial class Renewalcode_tableDao
	{
		public Renewalcode_tableDao()
		{}
		
        #region  基础方法======

		/// <summary>
		/// 得到最大ID
		/// </summary>
		public int GetMaxId()
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select top 1 rnwCode from Renewalcode_table order by rnwCode desc");
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
                return 0;
            else
                return Convert.ToInt32(obj);
		}

		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(int rnwCode)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from Renewalcode_table");
            strSql.Append(" where [rnwCode]=@rnwCode");
            SqlParameter[] parameters = {
                            new SqlParameter("@rnwCode",SqlDbType.Int)};

            parameters[0].Value = rnwCode;
            return DbHelperSQL.Exists(strSql.ToString(), parameters);
		}


		/// <summary>
		/// 增加一条数据
		/// </summary>
		public int Add(Renewalcode_tableInfo model)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into Renewalcode_table");
            strSql.Append("([userId],[pkgId],[codeCount],[crtTime],[useTime])");
            strSql.Append(" values ");
            strSql.Append("(@userId,@pkgId,@codeCount,@crtTime,@useTime);");
            strSql.Append("select @@identity");
            SqlParameter[] parameters = {
                    new SqlParameter("@userId",SqlDbType.Int),
                    new SqlParameter("@pkgId",SqlDbType.Int),
                    new SqlParameter("@codeCount",SqlDbType.Int),
                    new SqlParameter("@crtTime",SqlDbType.DateTime),
                    new SqlParameter("@useTime",SqlDbType.DateTime)};
            
            parameters[0].Value = model.userId;
            parameters[1].Value = model.pkgId;
            parameters[2].Value = model.codeCount;
            parameters[3].Value = model.crtTime;
            parameters[4].Value = model.useTime;


            object obj = DbHelperSQL.GetSingle(strSql.ToString(), parameters);
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(Renewalcode_tableInfo model)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("UPDATE [Renewalcode_table] SET ");
            strSql.Append("[userId] = @userId,");
            strSql.Append("[pkgId] = @pkgId,");
            strSql.Append("[codeCount] = @codeCount,");
            strSql.Append("[crtTime] = @crtTime,");
            strSql.Append("[useTime] = @useTime ");
            strSql.Append(" where [rnwCode]=@rnwCode");

            SqlParameter[] parameters = {
                    new SqlParameter("@rnwCode",SqlDbType.VarChar),
                    new SqlParameter("@userId",SqlDbType.Int),
                    new SqlParameter("@pkgId",SqlDbType.Int),
                    new SqlParameter("@codeCount",SqlDbType.Int),
                    new SqlParameter("@crtTime",SqlDbType.DateTime),
                    new SqlParameter("@useTime",SqlDbType.DateTime)};

            parameters[0].Value = model.rnwCode;
            parameters[1].Value = model.userId;
            parameters[2].Value = model.pkgId;
            parameters[3].Value = model.codeCount;
            parameters[4].Value = model.crtTime;
            parameters[5].Value = model.useTime;


            int rows = DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
            
		}

        /// <summary>
        /// DataSet转List
        /// </summary>
        public List<Renewalcode_tableInfo> DataSetToList(DataSet ds,bool isPaging, out int recordCount)
        {
            List<Renewalcode_tableInfo> list = new List<Renewalcode_tableInfo>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                list.Add(DataRowToModel(row));
            }
            if (isPaging)
            {
                recordCount = Convert.ToInt32(ds.Tables[1].Rows[0]["recordCount"]);
            }
            else
            {
                recordCount = 0;
            }
            return list;
        }

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(int rnwCode)
		{

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from Renewalcode_table ");
            strSql.Append("where [rnwCode]=@rnwCode");
            SqlParameter[] parameters = {
					new SqlParameter("@rnwCode", SqlDbType.Int)};
            parameters[0].Value = rnwCode;

            int rows = DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }            
		}

        /// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ");
            if (Top > 0)
            {
                strSql.Append(" top " + Top.ToString());
            }
            strSql.Append("  * FROM Renewalcode_table");

            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }

            if(filedOrder.Trim() != "")
            {
                strSql.Append(" order by " + filedOrder);
            }
            
            return DbHelperSQL.Query(strSql.ToString());
		}

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select * FROM Renewalcode_table");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }

            return Convert.ToInt32(DbHelperSQL.GetSingle(PagingHelper.CreateCountingSql(strSql.ToString())));
         
        }

        /// <summary>
        /// 分页数据
        /// </summary>
        public DataSet GetList(int pageIndex, int pageSize, string strWhere, string filedOrder)
		{
            StringBuilder strSql = new StringBuilder();
            
            //这里拼接单表或者多表都可以
            strSql.Append("select * FROM Renewalcode_table"); 
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperSQL.Query(PagingHelper.CreatePagingSql(pageIndex, pageSize, strSql.ToString(), filedOrder));

		}

		/// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string newsidlist )
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from Renewalcode_table ");
            strSql.Append("where [rnwCode]  in (" + newsidlist + ")");
            int rows = DbHelperSQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Renewalcode_tableInfo GetModel(int rnwCode)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select top 1 * from Renewalcode_table ");
            strSql.Append("where [rnwCode]=@rnwCode");

            Renewalcode_tableInfo model=new Renewalcode_tableInfo();

            SqlParameter[] parameters = {
					new SqlParameter("@rnwCode", SqlDbType.Int,4)};
            parameters[0].Value = rnwCode;

            DataSet ds = DbHelperSQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
		}

        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Renewalcode_tableInfo GetModelBy(string where,string filedOrder)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select top 1 * from Renewalcode_table ");
            if (!string.IsNullOrEmpty(where))
            {
                strSql.Append(" where " + where);
            }
            if (!string.IsNullOrEmpty(filedOrder))
            {
                strSql.Append(" order by " + filedOrder);
            }

            DataSet ds = DbHelperSQL.Query(strSql.ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }
        
        #endregion  

        #region 私有方法======
		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		/// <summary>
        /// DataRow 转为实体类
        /// </summary>
        private Renewalcode_tableInfo DataRowToModel(DataRow row)
        {
            Renewalcode_tableInfo model = new Renewalcode_tableInfo();
            if (row != null)
            {
              

                if (row["rnwCode"] != null)
                {
                    model.rnwCode = row["rnwCode"].ToString();
                }

                if (row["userId"] != null && row["userId"].ToString() != "")
                {
                    model.userId = int.Parse(row["userId"].ToString());
                }

                if (row["pkgId"] != null && row["pkgId"].ToString() != "")
                {
                    model.pkgId = int.Parse(row["pkgId"].ToString());
                }


                if (row["codeCount"] != null && row["codeCount"].ToString() != "")
                {
                    model.codeCount = int.Parse(row["codeCount"].ToString());
                }

                if (row["crtTime"] != null && row["crtTime"].ToString() != "")
                {
                    model.crtTime = DateTime.Parse(row["crtTime"].ToString());
                }

                if (row["useTime"] != null && row["useTime"].ToString() != "")
                {
                    model.useTime = DateTime.Parse(row["useTime"].ToString());
                } 
                
            }
            return model;
        }

		#endregion  BasicMethod

	}
}

