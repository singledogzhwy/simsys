﻿/**  版本信息模板在安装目录下，可自行修改。
* order_tableDao.cs
*
* 功 能： N/A
* 类 名： order_tableDao
*
* Ver    变更日期             负责人  变更内容
* ───────────────────────────────────
* V0.01  2014/2/1 14:33:28   N/A    初版
*
* Copyright (c) 2012 Maticsoft Corporation. All rights reserved.
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：　　　　　　　　　　　　　　│
*└──────────────────────────────────┘
*/
using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Reflection;
using HZ.Model;
using HZ.DBUtility;
using HZ.DAL;

namespace HZ.DAL
{
	/// <summary>
	/// 数据访问类:order_table
	/// </summary>
	public partial class order_tableDao
	{
		public order_tableDao()
		{}
		
        #region  基础方法======

		/// <summary>
		/// 得到最大ID
		/// </summary>
		public int GetMaxId()
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select top 1 orderId from order_table order by orderId desc");
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
                return 0;
            else
                return Convert.ToInt32(obj);
		}

		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(int orderId)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from order_table");
            strSql.Append(" where [orderId]=@orderId");
            SqlParameter[] parameters = {
                            new SqlParameter("@orderId",SqlDbType.Int)};

            parameters[0].Value = orderId;
            return DbHelperSQL.Exists(strSql.ToString(), parameters);
		}


		/// <summary>
		/// 增加一条数据
		/// </summary>
		public int Add(order_tableInfo model)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into order_table");
            strSql.Append("([sim],[iccid],[cardType],[pkgId],[prepackageid],[userId],[price],[rnwStatus],[failReason],[rnwTime],[orderType],[3rdOrderid],[mchid],[rcvName],[payName],[accessName])");
            strSql.Append(" values ");
            strSql.Append("(@sim,@iccid,@cardType,@pkgId,@prepackageid,@userId,@price,@rnwStatus,@failReason,@rnwTime,@orderType,@ThrdOrderid,@mchid,@rcvName,@payName,@accessName);");
            strSql.Append("select @@identity");
            SqlParameter[] parameters = {
                    new SqlParameter("@sim",SqlDbType.BigInt),
                    new SqlParameter("@iccid",SqlDbType.VarChar),
                    new SqlParameter("@cardType",SqlDbType.VarChar),
                    new SqlParameter("@pkgId",SqlDbType.Int),
                    new SqlParameter("@prepackageid",SqlDbType.Int),
                    new SqlParameter("@userId",SqlDbType.VarChar),
                    new SqlParameter("@price",SqlDbType.Float),
                    new SqlParameter("@rnwStatus",SqlDbType.Bit),
                    new SqlParameter("@failReason",SqlDbType.VarChar),
                    new SqlParameter("@rnwTime",SqlDbType.DateTime),
                    new SqlParameter("@orderType",SqlDbType.Int),
                    new SqlParameter("@ThrdOrderid",SqlDbType.VarChar),
                    new SqlParameter("@mchid",SqlDbType.VarChar),
                    new SqlParameter("@rcvName",SqlDbType.VarChar),
                    new SqlParameter("@payName",SqlDbType.VarChar),
                    new SqlParameter("@accessName",SqlDbType.VarChar)};
            
            parameters[0].Value = model.sim;
            parameters[1].Value = model.iccid;
            parameters[2].Value = model.cardType;
            parameters[3].Value = model.pkgId;
            parameters[4].Value = model.prepackageid;
            parameters[5].Value = model.userId;
            parameters[6].Value = model.price;
            parameters[7].Value = model.rnwStatus;
            parameters[8].Value = model.failReason;
            parameters[9].Value = model.rnwTime;
            parameters[10].Value = model.orderType;
            parameters[11].Value = model.ThrdOrderid;
            parameters[12].Value = model.mchid;
            parameters[13].Value = model.rcvName;
            parameters[14].Value = model.payName;
            parameters[15].Value = model.accessName;


            object obj = DbHelperSQL.GetSingle(strSql.ToString(), parameters);
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(order_tableInfo model)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("UPDATE [order_table] SET ");
            strSql.Append("[sim] = @sim,");
            strSql.Append("[iccid] = @iccid,");
            strSql.Append("[cardType] = @cardType,");
            strSql.Append("[pkgId] = @pkgId,");
            strSql.Append("[prepackageid] = @prepackageid,");
            strSql.Append("[userId] = @userId,");
            strSql.Append("[price] = @price,");
            strSql.Append("[rnwStatus] = @rnwStatus,");
            strSql.Append("[failReason] = @failReason,");
            strSql.Append("[rnwTime] = @rnwTime,");
            strSql.Append("[orderType] = @orderType,");
            strSql.Append("[3rdOrderid] = @ThrdOrderid,");
            strSql.Append("[mchid] = @mchid,");
            strSql.Append("[rcvName] = @rcvName,");
            strSql.Append("[payName] = @payName,");
            strSql.Append("[accessName] = @accessName ");
            strSql.Append(" where [orderId]=@orderId");

            SqlParameter[] parameters = {
                    new SqlParameter("@orderId",SqlDbType.VarChar),
                    new SqlParameter("@sim",SqlDbType.BigInt),
                    new SqlParameter("@iccid",SqlDbType.VarChar),
                    new SqlParameter("@cardType",SqlDbType.VarChar),
                    new SqlParameter("@pkgId",SqlDbType.Int),
                    new SqlParameter("@prepackageid",SqlDbType.Int),
                    new SqlParameter("@userId",SqlDbType.VarChar),
                    new SqlParameter("@price",SqlDbType.Float),
                    new SqlParameter("@rnwStatus",SqlDbType.Bit),
                    new SqlParameter("@failReason",SqlDbType.VarChar),
                    new SqlParameter("@rnwTime",SqlDbType.DateTime),
                    new SqlParameter("@orderType",SqlDbType.Int),
                    new SqlParameter("@ThrdOrderid",SqlDbType.VarChar),
                    new SqlParameter("@mchid",SqlDbType.VarChar),
                    new SqlParameter("@rcvName",SqlDbType.VarChar),
                    new SqlParameter("@payName",SqlDbType.VarChar),
                    new SqlParameter("@accessName",SqlDbType.VarChar)};

            parameters[0].Value = model.orderId;
            parameters[1].Value = model.sim;
            parameters[2].Value = model.iccid;
            parameters[3].Value = model.cardType;
            parameters[4].Value = model.pkgId;
            parameters[5].Value = model.prepackageid;
            parameters[6].Value = model.userId;
            parameters[7].Value = model.price;
            parameters[8].Value = model.rnwStatus;
            parameters[9].Value = model.failReason;
            parameters[10].Value = model.rnwTime;
            parameters[11].Value = model.orderType;
            parameters[12].Value = model.ThrdOrderid;
            parameters[13].Value = model.mchid;
            parameters[14].Value = model.rcvName;
            parameters[15].Value = model.payName;
            parameters[16].Value = model.accessName;


            int rows = DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
            
		}

        /// <summary>
        /// DataSet转List
        /// </summary>
        public List<order_tableInfo> DataSetToList(DataSet ds,bool isPaging, out int recordCount)
        {
            List<order_tableInfo> list = new List<order_tableInfo>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                list.Add(DataRowToModel(row));
            }
            if (isPaging)
            {
                recordCount = Convert.ToInt32(ds.Tables[1].Rows[0]["recordCount"]);
            }
            else
            {
                recordCount = 0;
            }
            return list;
        }

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(int orderId)
		{

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from order_table ");
            strSql.Append("where [orderId]=@orderId");
            SqlParameter[] parameters = {
					new SqlParameter("@orderId", SqlDbType.Int)};
            parameters[0].Value = orderId;

            int rows = DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }            
		}

        /// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ");
            if (Top > 0)
            {
                strSql.Append(" top " + Top.ToString());
            }
            strSql.Append("  * FROM order_table");

            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }

            if(filedOrder.Trim() != "")
            {
                strSql.Append(" order by " + filedOrder);
            }
            
            return DbHelperSQL.Query(strSql.ToString());
		}

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select * FROM order_table");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }

            return Convert.ToInt32(DbHelperSQL.GetSingle(PagingHelper.CreateCountingSql(strSql.ToString())));
         
        }

        /// <summary>
        /// 分页数据
        /// </summary>
        public DataSet GetList(int pageIndex, int pageSize, string strWhere, string filedOrder)
		{
            StringBuilder strSql = new StringBuilder();
            
            //这里拼接单表或者多表都可以
            strSql.Append("select * FROM order_table"); 
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperSQL.Query(PagingHelper.CreatePagingSql(pageIndex, pageSize, strSql.ToString(), filedOrder));

		}

		/// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string newsidlist )
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from order_table ");
            strSql.Append("where [orderId]  in (" + newsidlist + ")");
            int rows = DbHelperSQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public order_tableInfo GetModel(int orderId)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select top 1 * from order_table ");
            strSql.Append("where [orderId]=@orderId");

            order_tableInfo model=new order_tableInfo();

            SqlParameter[] parameters = {
					new SqlParameter("@orderId", SqlDbType.Int,4)};
            parameters[0].Value = orderId;

            DataSet ds = DbHelperSQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
		}

        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public order_tableInfo GetModelBy(string where,string filedOrder)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select top 1 * from order_table ");
            if (!string.IsNullOrEmpty(where))
            {
                strSql.Append(" where " + where);
            }
            if (!string.IsNullOrEmpty(filedOrder))
            {
                strSql.Append(" order by " + filedOrder);
            }

            DataSet ds = DbHelperSQL.Query(strSql.ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }
        
        #endregion  

        #region 私有方法======
		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		/// <summary>
        /// DataRow 转为实体类
        /// </summary>
        private order_tableInfo DataRowToModel(DataRow row)
        {
            order_tableInfo model = new order_tableInfo();
            if (row != null)
            {
                if (row["orderId"] != null)
                {
                    model.orderId = row["orderId"].ToString();
                }

                if (row["iccid"] != null)
                {
                    model.iccid = row["iccid"].ToString();
                }

                if (row["sim"] != null && row["sim"].ToString() != "")
                {
                    model.sim = int.Parse(row["sim"].ToString());
                }

                if (row["pkgId"] != null && row["pkgId"].ToString() != "")
                {
                    model.pkgId = int.Parse(row["pkgId"].ToString());
                }

                if (row["cardType"] != null)
                {
                    model.cardType = row["cardType"].ToString();
                }

                if (row["userId"] != null)
                {
                    model.userId = row["userId"].ToString();
                }

                if (row["price"] != null)
                {
                    model.price = double.Parse(row["price"].ToString());
                }



                if (row["rnwStatus"] != null && row["rnwStatus"].ToString() != "")
                {
                    if ((row["rnwStatus"].ToString() == "1") || (row["rnwStatus"].ToString().ToLower() == "true"))
                    {
                        model.rnwStatus = true;
                    }
                    else
                    {
                        model.rnwStatus = false;
                    }
                }

                if (row["failReason"] != null)
                {
                    model.failReason = row["failReason"].ToString();
                }

                if (row["rnwTime"] != null && row["rnwTime"].ToString() != "")
                {
                    model.rnwTime = DateTime.Parse(row["rnwTime"].ToString());
                }


                if (row["orderType"] != null && row["orderType"].ToString() != "")
                {
                    model.orderType = int.Parse(row["orderType"].ToString());
                }

                if (row["ThrdOrderid"] != null)
                {
                    model.ThrdOrderid = row["ThrdOrderid"].ToString();
                }

                if (row["mchid"] != null)
                {
                    model.mchid = row["mchid"].ToString();
                }

                if (row["rcvName"] != null)
                {
                    model.rcvName = row["rcvName"].ToString();
                }

                if (row["payName"] != null)
                {
                    model.payName = row["payName"].ToString();
                }

                if (row["accessName"] != null)
                {
                    model.accessName = row["accessName"].ToString();
                }
            }
            return model;
        }

		#endregion  BasicMethod

	}
}

