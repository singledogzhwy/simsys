﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HZ.DAL
{
    public static class PagingHelper
    {
        /// <summary>
        /// 获取分页SQL语句，默认row_number为关健字，所有表不允许使用该字段名
        /// </summary>
        /// <param name="pageIndex">当前页数</param>
        /// <param name="pageSize">每页记录数</param>
        /// <param name="safeSql">SQL查询语句</param>
        /// <param name="orderField">排序字段,多个用逗号隔开</param>
        /// <param name="getCount">是否获取总页数</param>
        /// <returns></returns>
        public static string CreatePagingSql(int pageIndex, int pageSize, string safeSql, string orderField)
        {
            //拼接SQL字符串,加上ROW_NUMBER函数进行分页
            StringBuilder pageSql = new StringBuilder();
            pageSql.AppendFormat("SELECT ROW_NUMBER() OVER(ORDER BY {0}) as row_number,", orderField);
            pageSql.AppendFormat(safeSql.Substring(safeSql.ToUpper().IndexOf("SELECT") + 6));

            //拼接最终SQL
            StringBuilder newSql = new StringBuilder();
            newSql.Append("SELECT * FROM (");
            newSql.Append(pageSql.ToString());
            newSql.Append(") AS T");
            newSql.AppendFormat(" WHERE row_number between {0} and {1};", ((pageIndex - 1) * pageSize) + 1, pageIndex * pageSize);
            newSql.AppendFormat("SELECT COUNT(1) AS recordCount FROM ({0}) AS T;", safeSql);

           
            return newSql.ToString();

        }

        /// <summary>
        /// 获取记录总数SQL语句
        /// </summary>
        /// <param name="_safeSql">SQL查询语句</param>
        /// <returns>记录总数SQL语句</returns>
        public static string CreateCountingSql(string _safeSql)
        {
            return string.Format(" SELECT COUNT(1) AS RecordCount FROM ({0}) AS T", _safeSql);
        }
    }
}
