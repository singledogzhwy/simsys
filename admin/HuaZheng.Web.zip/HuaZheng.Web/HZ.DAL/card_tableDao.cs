﻿/**  版本信息模板在安装目录下，可自行修改。
* card_tableDao.cs
*
* 功 能： N/A
* 类 名： card_tableDao
*
* Ver    变更日期             负责人  变更内容
* ───────────────────────────────────
* V0.01  2014/2/1 14:33:28   N/A    初版
*
* Copyright (c) 2012 Maticsoft Corporation. All rights reserved.
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：　　　　　　　　　　　　　　│
*└──────────────────────────────────┘
*/
using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Reflection;
using HZ.Model;
using HZ.DBUtility;
using HZ.DAL;



namespace HZ.DAL
{
	/// <summary>
	/// 数据访问类:card_table
	/// </summary>
	public partial class card_tableDao
	{
		public card_tableDao()
		{}
		
        #region  基础方法======

		/// <summary>
		/// 得到最大ID
		/// </summary>
		public int GetMaxId()
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select top 1 sim from card_table order by sim desc");
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
                return 0;
            else
                return Convert.ToInt32(obj);
		}

		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(int sim)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from card_table");
            strSql.Append(" where [sim]=@sim");
            SqlParameter[] parameters = {
                            new SqlParameter("@sim",SqlDbType.Int)};

            parameters[0].Value = sim;
            return DbHelperSQL.Exists(strSql.ToString(), parameters);
		}


		/// <summary>
		/// 增加一条数据
		/// </summary>
		public int Add(card_tableInfo model)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into card_table");
            strSql.Append("([ICCID],[userId],[pkgId],[initialPeriod],[initialValue],[balance],[spsFlow],[isOpen],[isRunsout],[isActive],[getcardTime],[soldTime],[activateTime],[expireTime],[manualStoptime],[manualStarttime],[lastactivateTime],[isGprs],[isMessage],[cardType],[isRealname],[terminal],[destory])");
            strSql.Append(" values ");
            strSql.Append("(@ICCID,@userId,@pkgId,@initialPeriod,@initialValue,@balance,@spsFlow,@isOpen,@isRunsout,@isActive,@getcardTime,@soldTime,@activateTime,@expireTime,@manualStoptime,@manualStarttime,@lastactivateTime,@isGprs,@isMessage,@cardType,@isRealname,@terminal,@destory);");
            strSql.Append("select @@identity");
            SqlParameter[] parameters = {
                    new SqlParameter("@ICCID",SqlDbType.VarChar),
                    new SqlParameter("@userId",SqlDbType.Int),
                    new SqlParameter("@pkgId",SqlDbType.Int),
                    new SqlParameter("@initialPeriod",SqlDbType.VarChar),
                    new SqlParameter("@initialValue",SqlDbType.VarChar),
                    new SqlParameter("@balance",SqlDbType.Float),
                    new SqlParameter("@spsFlow",SqlDbType.Float),
                    new SqlParameter("@isOpen",SqlDbType.Bit),
                    new SqlParameter("@isRunsout",SqlDbType.Bit),
                    new SqlParameter("@isActive",SqlDbType.Bit),
                    new SqlParameter("@getcardTime",SqlDbType.DateTime),
                    new SqlParameter("@soldTime",SqlDbType.DateTime),
                    new SqlParameter("@activateTime",SqlDbType.DateTime),
                    new SqlParameter("@expireTime",SqlDbType.DateTime),
                    new SqlParameter("@manualStoptime",SqlDbType.DateTime),
                    new SqlParameter("@manualStarttime",SqlDbType.DateTime),
                    new SqlParameter("@lastactivateTime",SqlDbType.DateTime),
                    new SqlParameter("@isGprs",SqlDbType.Bit),
                    new SqlParameter("@isMessage",SqlDbType.Bit),
                    new SqlParameter("@cardType",SqlDbType.Int),
                    new SqlParameter("@isRealname",SqlDbType.Bit),
                    new SqlParameter("@terminal",SqlDbType.VarChar),
                    new SqlParameter("@destory",SqlDbType.Bit)};
            
            parameters[0].Value = model.ICCID;
            parameters[1].Value = model.userId;
            parameters[2].Value = model.pkgId;
            parameters[3].Value = model.initialPeriod;
            parameters[4].Value = model.initialValue;
            parameters[5].Value = model.balance;
            parameters[6].Value = model.spsFlow;
            parameters[7].Value = model.isOpen;
            parameters[8].Value = model.isRunsout;
            parameters[9].Value = model.isActive;
            parameters[10].Value = model.getcardTime;
            parameters[11].Value = model.soldTime;
            parameters[12].Value = model.activateTime;
            parameters[13].Value = model.expireTime;
            parameters[14].Value = model.manualStoptime;
            parameters[15].Value = model.manualStarttime;
            parameters[16].Value = model.lastactivateTime;
            parameters[17].Value = model.isGprs;
            parameters[18].Value = model.isMessage;
            parameters[19].Value = model.cardType;
            parameters[20].Value = model.isRealname;
            parameters[21].Value = model.terminal;
            parameters[22].Value = model.destory;


            object obj = DbHelperSQL.GetSingle(strSql.ToString(), parameters);
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
		}

		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(card_tableInfo model)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("UPDATE [card_table] SET ");
            strSql.Append("[ICCID] = @ICCID,");
            strSql.Append("[userId] = @userId,");
            strSql.Append("[pkgId] = @pkgId,");
            strSql.Append("[initialPeriod] = @initialPeriod,");
            strSql.Append("[initialValue] = @initialValue,");
            strSql.Append("[balance] = @balance,");
            strSql.Append("[spsFlow] = @spsFlow,");
            strSql.Append("[isOpen] = @isOpen,");
            strSql.Append("[isRunsout] = @isRunsout,");
            strSql.Append("[isActive] = @isActive,");
            strSql.Append("[getcardTime] = @getcardTime,");
            strSql.Append("[soldTime] = @soldTime,");
            strSql.Append("[activateTime] = @activateTime,");
            strSql.Append("[expireTime] = @expireTime,");
            strSql.Append("[manualStoptime] = @manualStoptime,");
            strSql.Append("[manualStarttime] = @manualStarttime,");
            strSql.Append("[lastactivateTime] = @lastactivateTime,");
            strSql.Append("[isGprs] = @isGprs,");
            strSql.Append("[isMessage] = @isMessage,");
            strSql.Append("[cardType] = @cardType,");
            strSql.Append("[isRealname] = @isRealname,");
            strSql.Append("[terminal] = @terminal,");
            strSql.Append("[destory] = @destory ");
            strSql.Append(" where [sim]=@sim");

            SqlParameter[] parameters = {
                    new SqlParameter("@sim",SqlDbType.BigInt),
                    new SqlParameter("@ICCID",SqlDbType.VarChar),
                    new SqlParameter("@userId",SqlDbType.Int),
                    new SqlParameter("@pkgId",SqlDbType.Int),
                    new SqlParameter("@initialPeriod",SqlDbType.VarChar),
                    new SqlParameter("@initialValue",SqlDbType.VarChar),
                    new SqlParameter("@balance",SqlDbType.Float),
                    new SqlParameter("@spsFlow",SqlDbType.Float),
                    new SqlParameter("@isOpen",SqlDbType.Bit),
                    new SqlParameter("@isRunsout",SqlDbType.Bit),
                    new SqlParameter("@isActive",SqlDbType.Bit),
                    new SqlParameter("@getcardTime",SqlDbType.DateTime),
                    new SqlParameter("@soldTime",SqlDbType.DateTime),
                    new SqlParameter("@activateTime",SqlDbType.DateTime),
                    new SqlParameter("@expireTime",SqlDbType.DateTime),
                    new SqlParameter("@manualStoptime",SqlDbType.DateTime),
                    new SqlParameter("@manualStarttime",SqlDbType.DateTime),
                    new SqlParameter("@lastactivateTime",SqlDbType.DateTime),
                    new SqlParameter("@isGprs",SqlDbType.Bit),
                    new SqlParameter("@isMessage",SqlDbType.Bit),
                    new SqlParameter("@cardType",SqlDbType.Int),
                    new SqlParameter("@isRealname",SqlDbType.Bit),
                    new SqlParameter("@terminal",SqlDbType.VarChar),
                    new SqlParameter("@destory",SqlDbType.Bit)};

            parameters[0].Value = model.sim;
            parameters[1].Value = model.ICCID;
            parameters[2].Value = model.userId;
            parameters[3].Value = model.pkgId;
            parameters[4].Value = model.initialPeriod;
            parameters[5].Value = model.initialValue;
            parameters[6].Value = model.balance;
            parameters[7].Value = model.spsFlow;
            parameters[8].Value = model.isOpen;
            parameters[9].Value = model.isRunsout;
            parameters[10].Value = model.isActive;
            parameters[11].Value = model.getcardTime;
            parameters[12].Value = model.soldTime;
            parameters[13].Value = model.activateTime;
            parameters[14].Value = model.expireTime;
            parameters[15].Value = model.manualStoptime;
            parameters[16].Value = model.manualStarttime;
            parameters[17].Value = model.lastactivateTime;
            parameters[18].Value = model.isGprs;
            parameters[19].Value = model.isMessage;
            parameters[20].Value = model.cardType;
            parameters[21].Value = model.isRealname;
            parameters[22].Value = model.terminal;
            parameters[23].Value = model.destory;


            int rows = DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
            
		}

        /// <summary>
        /// DataSet转List
        /// </summary>
        public List<card_tableInfo> DataSetToList(DataSet ds,bool isPaging, out int recordCount)
        {
            List<card_tableInfo> list = new List<card_tableInfo>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                list.Add(DataRowToModel(row));
            }
            if (isPaging)
            {
                recordCount = Convert.ToInt32(ds.Tables[1].Rows[0]["recordCount"]);
            }
            else
            {
                recordCount = 0;
            }
            return list;
        }

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(int sim)
		{

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from card_table ");
            strSql.Append("where [sim]=@sim");
            SqlParameter[] parameters = {
					new SqlParameter("@sim", SqlDbType.Int)};
            parameters[0].Value = sim;

            int rows = DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }            
		}

        /// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ");
            if (Top > 0)
            {
                strSql.Append(" top " + Top.ToString());
            }
            strSql.Append("  * FROM card_table");

            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }

            if(filedOrder.Trim() != "")
            {
                strSql.Append(" order by " + filedOrder);
            }
            
            return DbHelperSQL.Query(strSql.ToString());
		}

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select * FROM card_table");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }

            return Convert.ToInt32(DbHelperSQL.GetSingle(PagingHelper.CreateCountingSql(strSql.ToString())));
         
        }

        /// <summary>
        /// 分页数据
        /// </summary>
        public DataSet GetList(int pageIndex, int pageSize, string strWhere, string filedOrder)
		{
            StringBuilder strSql = new StringBuilder();
            
            //这里拼接单表或者多表都可以
            strSql.Append("select * FROM card_table"); 
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperSQL.Query(PagingHelper.CreatePagingSql(pageIndex, pageSize, strSql.ToString(), filedOrder));

		}

		/// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string newsidlist )
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from card_table ");
            strSql.Append("where [sim]  in (" + newsidlist + ")");
            int rows = DbHelperSQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public card_tableInfo GetModel(int sim)
		{
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select top 1 * from card_table ");
            strSql.Append("where [sim]=@sim");

            card_tableInfo model=new card_tableInfo();

            SqlParameter[] parameters = {
					new SqlParameter("@sim", SqlDbType.Int,4)};
            parameters[0].Value = sim;

            DataSet ds = DbHelperSQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
		}

        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public card_tableInfo GetModelBy(string where,string filedOrder)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select top 1 * from card_table ");
            if (!string.IsNullOrEmpty(where))
            {
                strSql.Append(" where " + where);
            }
            if (!string.IsNullOrEmpty(filedOrder))
            {
                strSql.Append(" order by " + filedOrder);
            }

            DataSet ds = DbHelperSQL.Query(strSql.ToString());
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }
        
        #endregion  

        #region 私有方法======
		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		/// <summary>
        /// DataRow 转为实体类
        /// </summary>
        private card_tableInfo DataRowToModel(DataRow row)
        {
            card_tableInfo model = new card_tableInfo();
            if (row != null)
            {
                if (row["sim"] != null && row["sim"].ToString() != "")
                {
                    model.sim = int.Parse(row["sim"].ToString());
                }

                if (row["ICCID"] != null)
                {
                    model.ICCID = row["ICCID"].ToString();
                }

                if (row["userId"] != null && row["userId"].ToString() != "")
                {
                    model.userId = int.Parse(row["userId"].ToString());
                }

                if (row["pkgId"] != null && row["pkgId"].ToString() != "")
                {
                    model.pkgId = int.Parse(row["pkgId"].ToString());
                }

                if (row["initialPeriod"] != null)
                {
                    model.initialPeriod = row["initialPeriod"].ToString();
                }

                if (row["initialValue"] != null )
                {
                    model.initialValue = row["initialValue"].ToString();
                }

                if (row["balance"] != null)
                {
                    model.balance =double.Parse(row["balance"].ToString());
                }

                if (row["spsFlow"] != null)
                {
                    model.spsFlow = double.Parse(row["spsFlow"].ToString());
                }

                if (row["isOpen"] != null && row["isOpen"].ToString() != "")
                {
                    if ((row["isOpen"].ToString() == "1") || (row["isOpen"].ToString().ToLower() == "true"))
                    {
                        model.isOpen = true;
                    }
                    else
                    {
                        model.isOpen = false;
                    }
                }
                if (row["isRunsout"] != null && row["isRunsout"].ToString() != "")
                {
                    if ((row["isRunsout"].ToString() == "1") || (row["isRunsout"].ToString().ToLower() == "true"))
                    {
                        model.isRunsout = true;
                    }
                    else
                    {
                        model.isRunsout = false;
                    }
                }
                if (row["isActive"] != null && row["isActive"].ToString() != "")
                {
                    if ((row["isActive"].ToString() == "1") || (row["isActive"].ToString().ToLower() == "true"))
                    {
                        model.isActive = true;
                    }
                    else
                    {
                        model.isActive = false;
                    }
                }

                if (row["getcardTime"] != null && row["getcardTime"].ToString() != "")
                {
                    model.getcardTime = DateTime.Parse(row["getcardTime"].ToString());
                }

                if (row["soldTime"] != null && row["soldTime"].ToString() != "")
                {
                    model.soldTime = DateTime.Parse(row["soldTime"].ToString());
                }

                if (row["activateTime"] != null && row["activateTime"].ToString() != "")
                {
                    model.activateTime = DateTime.Parse(row["activateTime"].ToString());
                }

                if (row["expireTime"] != null && row["expireTime"].ToString() != "")
                {
                    model.expireTime = DateTime.Parse(row["expireTime"].ToString());
                }

                if (row["manualStoptime"] != null && row["manualStoptime"].ToString() != "")
                {
                    model.manualStoptime = DateTime.Parse(row["manualStoptime"].ToString());
                }

                if (row["manualStarttime"] != null && row["manualStarttime"].ToString() != "")
                {
                    model.manualStarttime = DateTime.Parse(row["manualStarttime"].ToString());
                }


                if (row["lastactivateTime"] != null && row["lastactivateTime"].ToString() != "")
                {
                    model.lastactivateTime = DateTime.Parse(row["lastactivateTime"].ToString());
                }

                if (row["isGprs"] != null && row["isGprs"].ToString() != "")
                {
                    if ((row["isGprs"].ToString() == "1") || (row["isGprs"].ToString().ToLower() == "true"))
                    {
                        model.isGprs = true;
                    }
                    else
                    {
                        model.isGprs = false;
                    }
                }

                if (row["isMessage"] != null && row["isMessage"].ToString() != "")
                {
                    if ((row["isMessage"].ToString() == "1") || (row["isMessage"].ToString().ToLower() == "true"))
                    {
                        model.isMessage = true;
                    }
                    else
                    {
                        model.isMessage = false;
                    }
                }

                if (row["isRealname"] != null && row["isRealname"].ToString() != "")
                {
                    if ((row["isRealname"].ToString() == "1") || (row["isRealname"].ToString().ToLower() == "true"))
                    {
                        model.isRealname = true;
                    }
                    else
                    {
                        model.isRealname = false;
                    }
                }

                if (row["cardType"] != null && row["cardType"].ToString() != "")
                {
                    model.cardType =int.Parse(row["cardType"].ToString());
                }

                if (row["terminal"] != null)
                {
                    model.terminal = row["terminal"].ToString();
                }

                if (row["destory"] != null && row["destory"].ToString() != "")
                {
                    if ((row["destory"].ToString() == "1") || (row["destory"].ToString().ToLower() == "true"))
                    {
                        model.destory = true;
                    }
                    else
                    {
                        model.destory = false;
                    }
                }
            }
            return model;
        }

		#endregion  BasicMethod

	}
}

